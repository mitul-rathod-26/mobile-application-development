# Android Studio - Beginner Setup Guide

> We will install Android Studio, create a new project, add an Activity, and run the app on both a virtual device and a real phone.

---

## Steps

- Install Android Studio
- Create your first Android project
- Understand the basic project structure
- Create a simple Activity (screen)
- Run the app on a Virtual Device (emulator)
- Run the app on a Physical Device (your phone)

---

## Step 1 — Download & Install Android Studio

1. Go to this link: **https://developer.android.com/studio**
2. Click the big **Download Android Studio** button
3. Open the downloaded file and follow the installer steps
4. When the installer asks about components, keep everything **checked by default** and click Next
5. Wait for the installation to finish (it may take 10–20 minutes)
6. Open Android Studio after installation

> **First time opening?** Android Studio will download some extra tools automatically. Let it finish before doing anything.

---

## Step 2 — Create a New Project

1. Open Android Studio
2. You will see a welcome screen — click **"New Project"**
3. A window will open asking you to choose a template
4. Select **"Empty Views Activity"** and click **Next**
5. Fill in the project details:

   | Field | What to type |
   |---|---|
   | Name | `MyApplication` |
   | Package name | `com.example.myapplication` |
   | Save location | Choose any folder on your computer |
   | Language | `Java` |
   | Minimum SDK | `API 24` (Android 7.0) |

6. Click **Finish**

7. Android Studio will take a minute to set up your project. Wait for the loading bar at the bottom to finish.

---

## Step 3 — Understand the Project Structure

After the project opens, look at the left side panel. You will see folders like this:

```
app/
 └── src/
      └── main/
           ├── java/com/example/myapplication/
           │    └── MainActivity.java        ← Your screen logic (Java code)
           ├── res/
           │    └── layout/
           │         └── activity_main.xml   ← Your screen design (XML)
           └── AndroidManifest.xml           ← App settings & registered screens
```

> **Simple rule:** Every screen in Android has 2 files — one `.java` file (logic) and one `.xml` file (design).

---

## Step 4 — Create a Simple Activity (New Screen)

An **Activity** is simply one screen in your app. Let's create a second screen called `SecondActivity`.

### 4.1 — Create a New Activity

Android Studio can create both files (Java + XML layout) for you at the same time!

1. In the left panel, right-click on the folder:
   `app → src → main → res → layout`
2. Click **New → Activity → Empty Views Activity**
3. Fill in the details:

   | Field | What to type |
   |---|---|
   | Activity Name | `SecondActivity` |
   | Layout Name | `activity_second` (fills automatically) |
   | Language | `Java` |

4. Click **Finish**

Android Studio will now automatically create:
- `SecondActivity.java` — inside the `java` folder
- `activity_second.xml` — inside the `res/layout` folder
- It also **registers the Activity** in `AndroidManifest.xml` for you!

Now open `activity_second.xml` and replace everything with this to add some content on the screen:

```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:gravity="center"
    android:orientation="vertical">

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Hello! This is Second Screen"
        android:textSize="20sp" />

</LinearLayout>
```

### 4.2 — Verify the Activity in AndroidManifest.xml

Since we used **New → Activity**, Android Studio already registered `SecondActivity` in `AndroidManifest.xml` automatically. Let's just confirm it.

1. Open `app → src → main → AndroidManifest.xml`
2. You should already see this line inside the `<application>` tag:

```xml
<activity android:name=".SecondActivity" android:exported="false" />
```

> **If it's missing** (rare case), add it manually just before `</application>`.

It should look like this:

```xml
<application ... >

    <activity android:name=".MainActivity" android:exported="true">
        <intent-filter>
            <action android:name="android.intent.action.MAIN" />
            <category android:name="android.intent.category.LAUNCHER" />
        </intent-filter>
    </activity>

    <!-- Add this line -->
    <activity android:name=".SecondActivity" android:exported="false" />

</application>
```

---

## Step 5 — Run on a Virtual Device (Emulator)

A **Virtual Device** is a fake phone that runs inside your computer. You don't need a real phone for this.

### 5.1 — Create a Virtual Device

1. In Android Studio, click on **Device Manager** (look for the phone icon on the right side toolbar, or go to **View → Tool Windows → Device Manager**)
2. Click **"+"** or **"Create Virtual Device"**
3. Select a phone model — choose **Pixel 6** (or any phone listed)
4. Click **Next**
5. Select a system image — choose **API 35** (if it shows a download button, click it and wait)
6. Click **Next**, then **Finish**

### 5.2 — Run the App

1. At the top of Android Studio, you will see a dropdown showing your virtual device name
2. Click the **green Play button ▶** (or press `Shift + F10`)
3. Wait for the emulator to start — this can take 1–2 minutes the first time
4. Your app will open automatically on the emulator!

> **Tip:** Keep the emulator open while you code. It will be faster to run the app again next time.

---

## Step 6 — Run on a Physical Device (Your Phone)

You can also run the app directly on your Android phone.

### 6.1 — Enable Developer Options on Your Phone

1. Open **Settings** on your phone
2. Go to **About Phone**
3. Find **Build Number** and tap it **7 times** quickly
4. You will see a message: *"You are now a developer!"*

### 6.2 — Enable USB Debugging

1. Go back to **Settings**
2. You will now see a new option called **Developer Options** (sometimes inside **System** or **Additional Settings**)
3. Open **Developer Options**
4. Turn on **USB Debugging**

### 6.3 — Connect Your Phone to the Computer

1. Connect your phone to your computer using a **USB cable**
2. A popup will appear on your phone asking: *"Allow USB Debugging?"*
3. Tap **Allow**
4. In Android Studio, look at the device dropdown at the top — your phone name should appear there
5. Select your phone from the dropdown
6. Click the **green Play button ▶**
7. The app will install and open on your phone!

> **Phone not showing up?** Try a different USB cable. Some cables are only for charging and don't transfer data.

---

## Step 7 — Version Fix (If You Get Build Errors)

If your project shows errors when building, it might be a version mismatch. Read the file **`ANDROID_VERSION_FIX.md`** in this project — it explains exactly what to change and why.

---

## Common Mistakes to Avoid

| Mistake | Fix |
|---|---|
| App crashes on launch | Make sure the Activity is registered in `AndroidManifest.xml` |
| "Cannot resolve symbol R" error | Click **Build → Clean Project**, then **Build → Rebuild Project** |
| Emulator is very slow | Enable **Hardware Acceleration** in your computer's BIOS, or use a physical device |
| Phone not detected | Enable USB Debugging and try a different USB cable |
| Build errors after creating project | Check `ANDROID_VERSION_FIX.md` in this project |

---

## You Are Ready! 🎉

You have:
- ✅ Installed Android Studio
- ✅ Created a new project
- ✅ Created a new Activity (screen)
- ✅ Run the app on a virtual device
- ✅ Run the app on a real phone

Now open the project files and read the code — every file has comments to help you understand what each line does.
