# Android Adapter Practical — SimpleAdapter with ListView

## What is an Adapter?

Think of an **Adapter** as a **bridge** between your **data** (like a list of fruits) and your **screen** (ListView).

- You have data → Adapter takes it → Shows it on screen in a list

---

## What We Are Building

A fruit list that shows:
- Fruit **name** (text)
- Fruit **image** (picture)

When you click any fruit → it shows the fruit name in a small popup (Toast).

---

## Flow — How It Works (Step by Step)

```
MainActivity
    |
    | (click "Adapter Demo" button)
    |
    v
SimpleAdapterExample (new screen)
    |
    | (creates data: fruit names + images)
    |
    v
SimpleAdapter (the bridge)
    |
    | (connects data to layout)
    |
    v
list_view_items.xml (one row design)
    |
    v
ListView (shows all rows on screen)
```

---

## Files Used in This Practical

| File | What it does |
|------|-------------|
| `MainActivity.java` | Has a button to open the Adapter screen |
| `activity_main.xml` | Layout of MainActivity (has the button) |
| `SimpleAdapterExample.java` | Main logic — creates data and sets adapter |
| `activity_simple_adapter_example.xml` | Layout that has the ListView |
| `list_view_items.xml` | Design of ONE row (text + image) |
| `drawable/` folder | Stores fruit images (apple.png, banana.png, etc.) |

---

## Step 1 — MainActivity Button (Entry Point)

**File:** `MainActivity.java`

This is the starting screen. It has a button called **"Adapter Demo"**.
When you click it, it opens `SimpleAdapterExample` screen.

```java
btnAdapter = findViewById(R.id.btnAdapter);

btnAdapter.setOnClickListener(view -> {
    Intent intent = new Intent(MainActivity.this, SimpleAdapterExample.class);
    startActivity(intent);
});
```

**File:** `activity_main.xml`

This XML has the button with id `btnAdapter`.

```xml
<Button
    android:id="@+id/btnAdapter"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content"
    android:text="Adapter Demo" />
```

---

## Step 2 — Design the List Row

**File:** `list_view_items.xml`

This is the design of **one single row** in the list.
Every fruit will use this same design — left side text, right side image.

```xml
<RelativeLayout ...>

    <!-- Fruit Name on the left -->
    <TextView
        android:id="@+id/textView"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:padding="20dp"
        android:text="Demo"
        android:textColor="#000" />

    <!-- Fruit Image on the right -->
    <ImageView
        android:id="@+id/imageView"
        android:layout_width="50dp"
        android:layout_height="50dp"
        android:layout_alignParentRight="true"
        android:layout_marginRight="10dp" />

</RelativeLayout>
```

> Think of this file as a **template** for each row. Adapter will fill in the real data.

---

## Step 3 — Design the Screen with ListView

**File:** `activity_simple_adapter_example.xml`

This screen has only one thing — a **ListView** that will show all the rows.

```xml
<RelativeLayout ...>

    <ListView
        android:id="@+id/simpleListView"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:divider="#000"
        android:dividerHeight="2dp" />

</RelativeLayout>
```

> `ListView` is like an empty container. The Adapter will fill it with rows.

---

## Step 4 — Write the Adapter Logic

**File:** `SimpleAdapterExample.java`

This is the most important file. Let's understand it part by part.

### 4.1 — Declare Fruit Data

```java
// List of fruit names
String[] fruits = {"Apple", "Banana", "Litchi", "Mango", "Pineapple"};

// List of fruit images (from drawable folder)
int[] images = {R.drawable.apple, R.drawable.banana, R.drawable.litchi,
                R.drawable.mango, R.drawable.pineapple};
```

> Both arrays are in the **same order** — index 0 is Apple with apple image, index 1 is Banana with banana image, and so on.

---

### 4.2 — Connect ListView from XML

```java
ListView listView = findViewById(R.id.simpleListView);
```

> This connects the ListView from XML to our Java code.

---

### 4.3 — Create ArrayList and HashMap

```java
ArrayList<HashMap<String, Object>> data = new ArrayList<>();
```

- **ArrayList** = a list that can hold many items (like a bag)
- **HashMap** = stores data as key-value pairs (like: `"name" → "Apple"`)
- So `data` is a **list of HashMaps** — one HashMap per fruit

```java
for (int i = 0; i < fruits.length; i++) {

    HashMap<String, Object> map = new HashMap<>();

    map.put("name", fruits[i]);    // key = "name",  value = "Apple"
    map.put("image", images[i]);   // key = "image", value = R.drawable.apple

    data.add(map);  // add this fruit's map into the list
}
```

**After the loop, `data` looks like this:**

```
data = [
  { "name": "Apple",     "image": R.drawable.apple     },
  { "name": "Banana",    "image": R.drawable.banana    },
  { "name": "Litchi",    "image": R.drawable.litchi    },
  { "name": "Mango",     "image": R.drawable.mango     },
  { "name": "Pineapple", "image": R.drawable.pineapple }
]
```

---

### 4.4 — Create SimpleAdapter

```java
SimpleAdapter adapter = new SimpleAdapter(
    this,                          // Context (current screen)
    data,                          // Our data (ArrayList of HashMaps)
    R.layout.list_view_items,      // Row design (list_view_items.xml)
    new String[]{"name", "image"}, // Keys from HashMap
    new int[]{R.id.textView, R.id.imageView}  // Views in list_view_items.xml
);
```

**How SimpleAdapter connects data to views:**

```
HashMap key "name"  ──────────────►  R.id.textView  (shows fruit name)
HashMap key "image" ──────────────►  R.id.imageView (shows fruit image)
```

---

### 4.5 — Set Adapter to ListView

```java
listView.setAdapter(adapter);
```

> This tells the ListView: "Use this adapter to fill yourself with rows."

---

### 4.6 — Handle Click on Each Row

```java
listView.setOnItemClickListener((parent, view, position, id) ->
    Toast.makeText(this, fruits[position], Toast.LENGTH_SHORT).show()
);
```

- `position` = the index of the row that was clicked (0, 1, 2...)
- `fruits[position]` = the fruit name at that index
- `Toast` = small popup message at the bottom of screen

---

## Complete Code — SimpleAdapterExample.java

```java
package com.example.myapplication;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.HashMap;

public class SimpleAdapterExample extends AppCompatActivity {

    String[] fruits = {"Apple", "Banana", "Litchi", "Mango", "Pineapple"};
    int[] images = {R.drawable.apple, R.drawable.banana, R.drawable.litchi,
                    R.drawable.mango, R.drawable.pineapple};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simple_adapter_example);

        ListView listView = findViewById(R.id.simpleListView);

        ArrayList<HashMap<String, Object>> data = new ArrayList<>();

        for (int i = 0; i < fruits.length; i++) {
            HashMap<String, Object> map = new HashMap<>();
            map.put("name", fruits[i]);
            map.put("image", images[i]);
            data.add(map);
        }

        SimpleAdapter adapter = new SimpleAdapter(this, data, R.layout.list_view_items,
                new String[]{"name", "image"},
                new int[]{R.id.textView, R.id.imageView});

        listView.setAdapter(adapter);

        listView.setOnItemClickListener((parent, view, position, id) ->
                Toast.makeText(this, fruits[position], Toast.LENGTH_SHORT).show()
        );
    }
}
```

---

## Don't Forget — Register Activity in AndroidManifest.xml

Every new Activity must be added in `AndroidManifest.xml` inside `<application>` tag.

```xml
<activity android:name=".SimpleAdapterExample" />
```

---

## Add Fruit Images to Drawable Folder

1. Copy your fruit images (apple.png, banana.png, litchi.png, mango.png, pineapple.png)
2. Paste them inside: `app > src > main > res > drawable`
3. Make sure the file names match exactly what you wrote in the `images[]` array

---

## Quick Summary

| What | Why |
|------|-----|
| `String[] fruits` | Stores fruit names |
| `int[] images` | Stores fruit image references |
| `HashMap` | Holds one fruit's name + image together |
| `ArrayList` | Holds all fruits' HashMaps |
| `SimpleAdapter` | Connects data to the row layout |
| `list_view_items.xml` | Design template for one row |
| `ListView` | Shows all rows on screen |
| `setOnItemClickListener` | Handles click on a row |

---

## Final Output

When you run the app:
1. You see **MainActivity** with buttons
2. Click **"Adapter Demo"** button
3. A new screen opens with a **list of fruits**
4. Each row shows **fruit name** on left and **fruit image** on right
5. Click any fruit → **Toast message** shows the fruit name
