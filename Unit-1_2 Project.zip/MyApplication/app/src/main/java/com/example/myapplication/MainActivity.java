package com.example.myapplication;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    Button btnExplicit, btnImplicit, btnAdapter, btnBroadcast, btnFragment, btnInternetResources;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        btnExplicit = findViewById(R.id.btnExplicit);
        btnImplicit = findViewById(R.id.btnImplicit);
        btnAdapter = findViewById(R.id.btnAdapter);

        btnExplicit.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, ExplicitIntent.class);
            /// Sending static data to ExplicitIntent activity using putExtra
            intent.putExtra("name", "Rahul Patel");
            intent.putExtra("mobile", "+91 6352569858");
            Toast.makeText(getApplicationContext(), "Navigate to Explicit Intent Screen", Toast.LENGTH_SHORT).show();
            startActivity(intent);
        });
        btnImplicit.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, ImplicitIntent.class);
            Toast.makeText(getApplicationContext(), "Navigate to Implicit Intent Screen", Toast.LENGTH_SHORT).show();
            startActivity(intent);
        });

        btnAdapter.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, SimpleAdapterExample.class);
            Toast.makeText(getApplicationContext(), "Navigate to Adapter Screen", Toast.LENGTH_SHORT).show();
            startActivity(intent);
        });

        btnBroadcast = findViewById(R.id.btnBroadcast);

        btnBroadcast.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, BroadcastDemo.class);
            Toast.makeText(getApplicationContext(), "Navigate to Broadcast Receiver Screen", Toast.LENGTH_SHORT).show();
            startActivity(intent);
        });

        btnFragment = findViewById(R.id.btnFragment);
        btnFragment.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, FragmentDemoActivity.class);
            startActivity(intent);
        });

        btnInternetResources = findViewById(R.id.btnInternetResources);
        btnInternetResources.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, InternetResourcesDemo.class);
            startActivity(intent);
        });
    }
}