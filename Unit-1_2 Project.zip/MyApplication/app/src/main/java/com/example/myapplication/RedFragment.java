package com.example.myapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

public class RedFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        // inflate = load the XML layout for this fragment into a View object
        View view = inflater.inflate(R.layout.fragment_red, container, false);

        // in fragment we use view.findViewById() — NOT just findViewById()
        // because fragment doesn't own the full screen, only its own view
        TextView txtRed = view.findViewById(R.id.txtRedText);
        txtRed.setText("🔴 This is Red Fragment");

        // always return the view at the end — this is what gets shown on screen
        return view;
    }
}
