package com.example.myapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

public class BlueFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        // inflate = load the XML layout for this fragment into a View object
        View view = inflater.inflate(R.layout.fragment_blue, container, false);

        // in fragment we use view.findViewById() — NOT just findViewById()
        // because fragment doesn't own the full screen, only its own view
        TextView txtBlue = view.findViewById(R.id.txtBlueText);
        txtBlue.setText("🔵 This is Blue Fragment");

        // always return the view at the end — this is what gets shown on screen
        return view;
    }
}
