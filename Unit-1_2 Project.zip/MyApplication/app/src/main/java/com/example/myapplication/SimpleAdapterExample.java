package com.example.myapplication;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;

public class SimpleAdapterExample extends AppCompatActivity {

    // this is list of fruit names
    String[] fruits = {"Apple", "Banana", "Litchi", "Mango", "Pineapple", "Apple", "Banana", "Litchi", "Mango", "Pineapple","Apple", "Banana", "Litchi", "Mango", "Pineapple","Apple", "Banana", "Litchi", "Mango", "Pineapple","Apple", "Banana", "Litchi", "Mango", "Pineapple", };

    // this is list of fruit images (stored in drawable folder)
    int[] images = {R.drawable.apple, R.drawable.banana, R.drawable.litchi, R.drawable.mango, R.drawable.pineapple, R.drawable.apple, R.drawable.banana, R.drawable.litchi, R.drawable.mango, R.drawable.pineapple,R.drawable.apple, R.drawable.banana, R.drawable.litchi, R.drawable.mango, R.drawable.pineapple,R.drawable.apple, R.drawable.banana, R.drawable.litchi, R.drawable.mango, R.drawable.pineapple,R.drawable.apple, R.drawable.banana, R.drawable.litchi, R.drawable.mango, R.drawable.pineapple,};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simple_adapter_example);

        // Connect ListView from XML to Java
        ListView listView = findViewById(R.id.simpleListView);

        // ArrayList = a list that holds multiple items (like a bag)
        ArrayList<HashMap<String, Object>> data = new ArrayList<>();

        for (int i = 0; i < fruits.length; i++) {

            // HashMap = stores data in key-value pair (like: "name" -> "Apple")
            HashMap<String, Object> map = new HashMap<>();

            map.put("name", fruits[i]);    // save fruit name with key "name"
            map.put("image", images[i]);   // save fruit image with key "image"

            data.add(map);   // add this fruit's data into the list
        }

        // SimpleAdapter connects our data to the list_view_items.xml layout
        // "name"  -> goes into textView
        // "image" -> goes into imageView
        SimpleAdapter adapter = new SimpleAdapter(this, data, R.layout.list_view_items,
                // keys from HashMap
                new String[]{"name", "image"},
                new int[]{R.id.textView, R.id.imageView});

        // Set the adapter to ListView so it can show the data
        listView.setAdapter(adapter);

        // When user clicks any item, show its name in a Toast message
        listView.setOnItemClickListener((parent, view, position, id) ->
                Toast.makeText(this, fruits[position], Toast.LENGTH_SHORT).show()
        );
    }
}
