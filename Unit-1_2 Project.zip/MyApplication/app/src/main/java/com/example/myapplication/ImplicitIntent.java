package com.example.myapplication;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class ImplicitIntent extends AppCompatActivity {
    Button btnOpenGoogle, btnCallDialer;

    Button btnBackToHome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_implicit_intent);

        /// for the connect each button to its view using the ID defined in XML layout
        btnOpenGoogle = findViewById(R.id.btnOpenGoogle);
        btnCallDialer = findViewById(R.id.btnCallDialer);
        btnBackToHome = findViewById(R.id.btnBackToHome);

        /// When user clicks "Open Google" button
        /// ACTION_VIEW + URL tells Android to open this link in a browser
        btnOpenGoogle.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"));
            Toast.makeText(this, "Opening Google...", Toast.LENGTH_SHORT).show();
            startActivity(intent);
        });

        /// When user clicks "Call Dialer" button
        /// ACTION_DIAL opens the phone dialer app (does NOT call directly, user has to press call)
        btnCallDialer.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            Toast.makeText(this, "Opening Call Dialer...", Toast.LENGTH_SHORT).show();
            startActivity(intent);
        });

        /// When user clicks "Back to Home" button
        /// This is an Explicit Intent - we directly specify which Activity to open
        btnBackToHome.setOnClickListener(view -> {
            Intent intent = new Intent(ImplicitIntent.this, MainActivity.class);
            Toast.makeText(getApplicationContext(), "Navigate to Home Screen", Toast.LENGTH_SHORT).show();
            startActivity(intent);
        });


    }
}