package com.example.myapplication;

import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class InternetResourcesDemo extends AppCompatActivity {

    // UI elements we use in this screen
    TextView resultTextView;  // shows the downloaded result
    ProgressBar progressBar;  // spinning loader shown while downloading
    Button loadJsonButton;    // button to load JSON data

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_internet_resources_demo);

        // Connect Java variables to the XML layout views
        resultTextView = findViewById(R.id.resultTextView);
        progressBar    = findViewById(R.id.progressBar);
        loadJsonButton = findViewById(R.id.loadJsonButton);

        // When button is clicked, call the matching method
        loadJsonButton.setOnClickListener(v -> downloadAndParseJson());
        findViewById(R.id.downloadPdfButton).setOnClickListener(v -> downloadPdf());
    }

    // ---------------------------------------------------------------
    // Part A: Download JSON data from internet and show it on screen
    // ---------------------------------------------------------------
    private void downloadAndParseJson() {
        showLoading(true);  // show spinner, disable button
        resultTextView.setText("Downloading JSON data...");

        // Network calls must run in a background thread (not on main/UI thread)
        new Thread(() -> {
            String output;
            HttpURLConnection connection = null;
            try {
                // Step 1: Open a connection to the URL
                connection = (HttpURLConnection) new URL(getString(R.string.product_api_url)).openConnection();
                connection.setConnectTimeout(10000); // wait max 10 sec to connect
                connection.setReadTimeout(10000);    // wait max 10 sec to read data

                // Step 2: Read the response line by line into a string
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) sb.append(line);
                reader.close();

                // Step 3: Parse the JSON string and pick the fields we need
                JSONObject product = new JSONObject(sb.toString());
                output = "Product Details\n\n"
                        + "Title: "    + product.getString("title")    + "\n"
                        + "Category: " + product.getString("category") + "\n"
                        + "Price: $"   + product.getDouble("price");

            } catch (Exception e) {
                // If anything goes wrong, show the error reason
                output = "Could not load data.\n\nReason: " + e.getMessage();
            } finally {
                // Always close the connection when done
                if (connection != null) connection.disconnect();
            }

            // Step 4: Go back to main thread to update the UI
            String finalOutput = output;
            runOnUiThread(() -> {
                resultTextView.setText(finalOutput);
                showLoading(false); // hide spinner, enable button
            });
        }).start(); // start the background thread
    }

    // ---------------------------------------------------------------
    // Part B: Use DownloadManager to download a PDF file
    // DownloadManager is a built-in Android service for file downloads
    // It handles everything: progress, retry, notification, storage
    // ---------------------------------------------------------------
    private void downloadPdf() {
        // Build a download request with file details
        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(getString(R.string.sample_pdf_url)))
                .setTitle("Sample Android PDF")                   // title shown in notification
                .setDescription("Downloading the practical PDF file") // description in notification
                .setMimeType("application/pdf")                   // file type
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED) // show notification when done
                .setAllowedOverMetered(true)                      // allow download on mobile data
                .setAllowedOverRoaming(false)                     // don't download on roaming
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "android-practical-sample.pdf"); // save location

        // Hand the request to DownloadManager and start the download
        DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
        if (dm != null) {
            // enqueue() adds the download to the queue and returns a unique ID
            Toast.makeText(this, "Download started. ID: " + dm.enqueue(request), Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "DownloadManager not available.", Toast.LENGTH_LONG).show();
        }
    }

    // ---------------------------------------------------------------
    // Helper: show or hide the loading spinner
    // ---------------------------------------------------------------
    private void showLoading(boolean isLoading) {
        progressBar.setVisibility(isLoading ? View.VISIBLE : View.GONE);
        loadJsonButton.setEnabled(!isLoading); // disable button while loading
    }
}
