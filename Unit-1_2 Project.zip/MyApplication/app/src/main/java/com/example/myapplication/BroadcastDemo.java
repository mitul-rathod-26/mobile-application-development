package com.example.myapplication;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class BroadcastDemo extends AppCompatActivity {

    TextView txtBatteryLevel, txtChargingStatus, txtBatteryHealth;
    Button btnBackToHome;

    /// save old values so we can compare later
    int lastBatteryPct = -1;
    boolean lastIsCharging = false;

    /// android calls this automatically when battery info changes
    /// The "antenna" class that listens for events
    BroadcastReceiver batteryReceiver = new BroadcastReceiver() {

        /// onReceive() - Code that runs automatically when event happens
        @Override
        public void onReceive(Context context, Intent intent) {

            /// level = current charge, scale = max charge (mostly 100)
            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);

            System.out.println("level ===>>> " + level);
            System.out.println("scale ===>>> " + scale);
             /* scale = 10   → "10" means fully charged
               level = 7    → currently at 7 out of 10

               (7 / 10) × 100 = 70%
             */

            int batteryPct = (level * 100) / scale;
            System.out.println("batteryPct ===>>> " + batteryPct);


            /// is phone charging right now?
            int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            boolean isCharging = (status == BatteryManager.BATTERY_STATUS_CHARGING);

            /// how is the battery condition
            int health = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, -1);
            String healthStatus;
            if (health == BatteryManager.BATTERY_HEALTH_GOOD) {
                healthStatus = "Good... ✅";
            } else if (health == BatteryManager.BATTERY_HEALTH_OVERHEAT) {
                healthStatus = "Overheat... 🔥";
            } else {
                healthStatus = "Unknown..?";
            }

            /// update screen with latest values
            txtBatteryLevel.setText("Battery Level: " + batteryPct + "%");
            txtChargingStatus.setText("Charging Status: " + (isCharging ? "Charging ⚡" : "Discharging 🔋"));
            txtBatteryHealth.setText("Battery Health: " + healthStatus);

            /// toast only if battery % is different from last time
            if (batteryPct != lastBatteryPct) {
                Toast.makeText(context, "Battery Level Changed: " + batteryPct + "%", Toast.LENGTH_SHORT).show();
                lastBatteryPct = batteryPct;
            }

            /// toast only if charging state changed (plugged/unplugged)
            if (isCharging != lastIsCharging) {
                Toast.makeText(context, isCharging ? "Phone is now Charging ⚡" : "Phone is now Discharging 🔋", Toast.LENGTH_SHORT).show();
                lastIsCharging = isCharging;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_broadcast_demo);

        txtBatteryLevel = findViewById(R.id.txtBatteryLevel);
        txtChargingStatus = findViewById(R.id.txtChargingStatus);
        txtBatteryHealth = findViewById(R.id.txtBatteryHealth);
        btnBackToHome = findViewById(R.id.btnBackToHome);

        /// register receiver — Android will call onReceive automatically when battery changes
        /// it will start listening
        registerReceiver(batteryReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));

        btnBackToHome.setOnClickListener(view -> {
            Intent intent = new Intent(BroadcastDemo.this, MainActivity.class);
            Toast.makeText(getApplicationContext(), "Navigate to Home Screen", Toast.LENGTH_SHORT).show();
            startActivity(intent);
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        /// unregister when screen closes
        /// stop listening (important!)
        unregisterReceiver(batteryReceiver);
    }
}
