package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class ExplicitIntent extends AppCompatActivity {

    Button btnBackToHome;
    TextView txtName, txtMobile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_explicit_intent);

        btnBackToHome = findViewById(R.id.btnBackToHome);
        txtName = findViewById(R.id.txtName);
        txtMobile = findViewById(R.id.txtMobile);

        /// Receiving the data sent from MainActivity using getIntent().getStringExtra()
        String name = getIntent().getStringExtra("name");
        String mobile = getIntent().getStringExtra("mobile");

        /// Display the received data in TextViews
        txtName.setText("Name: " + name);
        txtMobile.setText("Mobile: " + mobile);

        btnBackToHome.setOnClickListener(view -> {
            Intent intent = new Intent(ExplicitIntent.this, MainActivity.class);
            Toast.makeText(getApplicationContext(), "Navigate to Home Screen", Toast.LENGTH_SHORT).show();
            startActivity(intent);
        });

    }
}