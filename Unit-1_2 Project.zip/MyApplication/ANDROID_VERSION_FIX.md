# Android Project Version Compatibility Fix

### For only - Android Studio Ladybug | 2024.2.1 Patch 3

## Why This Issue Happens
When you create a new project, Android Studio picks the **latest versions** of dependencies automatically.
But if your Android Studio is **not the latest version**, those new dependencies may require a newer AGP than your Studio supports.

---

## Files Changed & What To Update

### 1. `gradle/libs.versions.toml`

**Old Code:**
```toml
[versions]
agp = "8.9.1"
activity = "1.12.4"
```

**New Code - Use this code:**
```toml
[versions]
agp = "8.7.3"
activity = "1.9.3"
```

- `agp 8.9.1` → `8.7.3` (match your Android Studio supported version)
- `activity 1.12.4` → `1.9.3` (compatible with AGP 8.7.3)

---

### 2. `app/build.gradle.kts`

**Old Code:**
```kotlin
android {
    compileSdk = 36

    defaultConfig {
        targetSdk = 36
    }
}
```

**New Code - Use this code:**
```kotlin
android {
    compileSdk = 35

    defaultConfig {
        targetSdk = 35
    }
}
```

- `compileSdk 36` → `35` (max supported by AGP 8.7.3)
- `targetSdk 36` → `35` (should always match compileSdk)

---

### 3. `gradle/wrapper/gradle-wrapper.properties`

**Old Code:**
```properties
distributionUrl=https\://services.gradle.org/distributions/gradle-8.11.1-bin.zip
```

**New Code - Use this code:**
```properties
distributionUrl=https\://services.gradle.org/distributions/gradle-8.9-bin.zip
```

- `gradle-8.11.1` → `gradle-8.9` (compatible with AGP 8.7.3)

---

## Summary Table

| File | What Changed |
|---|---|
| `gradle/libs.versions.toml` | `agp` and `activity` version downgraded |
| `app/build.gradle.kts` | `compileSdk` and `targetSdk` lowered to 35 |
| `gradle/wrapper/gradle-wrapper.properties` | Gradle version rolled back to 8.9 |

---

## Current Working Version Setup

| Tool | Version |
|---|---|
| Android Gradle Plugin (AGP) | 8.7.3 |
| Gradle Wrapper | 8.9 |
| compileSdk / targetSdk | 35 |
| androidx.activity | 1.9.3 |

---

## The Golden Rule

Always keep these 4 things in sync:

```
Android Studio version
       ↓ determines max supported
Android Gradle Plugin (AGP) version
       ↓ determines max supported
compileSdk / targetSdk
       ↓ determines compatible
Dependency versions (androidx.activity, core-ktx, etc.)
```

---

## Do I Need To Do This Every Time?

| Scenario | Fix Needed? |
|---|---|
| Updated Android Studio to latest | No |
| Using older Android Studio | Yes, check versions once per new project |

> **Permanent Solution:** Go to **Help → Check for Updates** in Android Studio and update to the latest version. New projects will then work out of the box.
