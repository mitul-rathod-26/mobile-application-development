# Fragment & Broadcast Receiver Practical

---

# PART 1 — Fragment

## What is a Fragment?

A **Fragment** is a **piece of a screen** that you can show inside an Activity.

- Think of Activity as a **picture frame**
- Fragment is the **picture** inside that frame
- You can **swap** the picture without changing the frame

> One Activity → Many Fragments (swap them on button click)

---

## What We Are Building

- One screen (`FragmentDemoActivity`) with **2 buttons** — Show Red, Show Blue
- Click **Show Red** → Red screen appears
- Click **Show Blue** → Blue screen appears
- No new Activity opens — just the fragment swaps inside the same screen

---

## Flow

```
MainActivity
    |
    | click "Fragment Demo"
    |
    v
FragmentDemoActivity
    |
    |-- [Show Red]  button  →  loads RedFragment  (red screen)
    |-- [Show Blue] button  →  loads BlueFragment (blue screen)
    |
    v
FrameLayout (empty container)
    ↑
    fragment appears here
```

---

## Files Used

| File | What it does |
|------|-------------|
| `MainActivity.java` | Has the "Fragment Demo" button |
| `activity_main.xml` | Layout with the button |
| `FragmentDemoActivity.java` | Loads Red or Blue fragment on button click |
| `activity_fragment_demo.xml` | Has 2 buttons + FrameLayout container |
| `RedFragment.java` | Shows red screen |
| `BlueFragment.java` | Shows blue screen |
| `fragment_red.xml` | Red layout design |
| `fragment_blue.xml` | Blue layout design |

---

## Step 1 — Add Button in MainActivity

**File:** `activity_main.xml`

Add a button with id `btnFragment`.

```xml
<Button
    android:id="@+id/btnFragment"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content"
    android:text="Fragment Demo"
    android:textStyle="bold" />
```

**File:** `MainActivity.java`

Wire the button to open `FragmentDemoActivity`.

```java
btnFragment = findViewById(R.id.btnFragment);

btnFragment.setOnClickListener(view -> {
    Intent intent = new Intent(MainActivity.this, FragmentDemoActivity.class);
    startActivity(intent);
});
```

---

## Step 2 — Design the Fragment Layouts

**File:** `fragment_red.xml` — full red background with a text label

```xml
<LinearLayout
    android:background="#FF0000"
    android:gravity="center"
    android:orientation="vertical" ...>

    <TextView
        android:text="🔴 RED FRAGMENT"
        android:textColor="#FFFFFF"
        android:textSize="28sp"
        android:textStyle="bold" />

    <TextView
        android:id="@+id/txtRedText"
        android:textColor="#FFFFFF"
        android:textSize="16sp" />

</LinearLayout>
```

**File:** `fragment_blue.xml` — same but blue background

```xml
<LinearLayout
    android:background="#0000FF"
    android:gravity="center"
    android:orientation="vertical" ...>

    <TextView
        android:text="🔵 BLUE FRAGMENT"
        android:textColor="#FFFFFF"
        android:textSize="28sp"
        android:textStyle="bold" />

    <TextView
        android:id="@+id/txtBlueText"
        android:textColor="#FFFFFF"
        android:textSize="16sp" />

</LinearLayout>
```

---

## Step 3 — Design the Fragment Demo Screen

**File:** `activity_fragment_demo.xml`

Two buttons on top + a `FrameLayout` below (this is where fragment will appear).

```xml
<LinearLayout android:orientation="vertical" ...>

    <!-- two buttons side by side -->
    <LinearLayout android:orientation="horizontal" ...>

        <Button android:id="@+id/btnRed"  android:text="Show Red"  android:backgroundTint="#FF0000" />
        <Button android:id="@+id/btnBlue" android:text="Show Blue" android:backgroundTint="#0000FF" />

    </LinearLayout>

    <!-- fragment will be loaded inside this box -->
    <FrameLayout
        android:id="@+id/fragmentContainer"
        android:layout_width="match_parent"
        android:layout_height="0dp"
        android:layout_weight="1" />

</LinearLayout>
```

> `FrameLayout` is just an **empty box**. We will put the fragment inside it from Java code.

---

## Step 4 — Write Fragment Classes

### RedFragment.java

```java
public class RedFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        // inflate = load the XML layout for this fragment into a View object
        View view = inflater.inflate(R.layout.fragment_red, container, false);

        // in fragment we use view.findViewById() — NOT just findViewById()
        // because fragment doesn't own the full screen, only its own view
        TextView txtRed = view.findViewById(R.id.txtRedText);
        txtRed.setText("🔴 This is Red Fragment");

        // always return the view at the end — this is what gets shown on screen
        return view;
    }
}
```

### BlueFragment.java

```java
public class BlueFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        // inflate = load the XML layout for this fragment into a View object
        View view = inflater.inflate(R.layout.fragment_blue, container, false);

        // in fragment we use view.findViewById() — NOT just findViewById()
        // because fragment doesn't own the full screen, only its own view
        TextView txtBlue = view.findViewById(R.id.txtBlueText);
        txtBlue.setText("🔵 This is Blue Fragment");

        // always return the view at the end — this is what gets shown on screen
        return view;
    }
}
```

---

## Step 5 — Write FragmentDemoActivity

**File:** `FragmentDemoActivity.java`

```java
public class FragmentDemoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment_demo);

        Button btnRed  = findViewById(R.id.btnRed);
        Button btnBlue = findViewById(R.id.btnBlue);

        // show Red Fragment when screen opens
        loadFragment(new RedFragment());

        btnRed.setOnClickListener(view  -> loadFragment(new RedFragment()));
        btnBlue.setOnClickListener(view -> loadFragment(new BlueFragment()));
    }

    private void loadFragment(Fragment fragment) {
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.fragmentContainer, fragment); // swap fragment inside the FrameLayout
        ft.commit();
    }
}
```

### How loadFragment() works

```
loadFragment(new RedFragment())
        |
        v
FragmentManager  →  manages all fragments in this activity
        |
        v
FragmentTransaction  →  like a "edit session" — begin, make changes, commit
        |
        v
ft.replace(container, fragment)  →  removes old fragment, puts new one
        |
        v
ft.commit()  →  apply the changes
```

---

## Step 6 — Register in AndroidManifest.xml

```xml
<activity android:name=".FragmentDemoActivity" android:exported="false" />
```

---

## Key Difference — Activity vs Fragment

| | Activity | Fragment |
|---|---|---|
| Layout loaded | `setContentView(R.layout.xxx)` | `inflater.inflate(R.layout.xxx, ...)` |
| Find view | `findViewById(R.id.xxx)` | `view.findViewById(R.id.xxx)` |
| Needs manifest? | ✅ Yes | ❌ No |
| Can be swapped? | ❌ No | ✅ Yes |

---

---

# PART 2 — Broadcast Receiver

## What is a Broadcast Receiver?

Android keeps sending **broadcasts** (system messages) all the time:
- Battery changed
- Phone charging / unplugged
- Internet connected / disconnected
- SMS received

A **BroadcastReceiver** is code that **listens** to these messages and reacts.

> Think of it like a **radio** — Android is the station broadcasting signals, your app is the radio that picks them up.

---

## What We Are Building

- A screen that **listens to battery broadcasts**
- Shows live: Battery %, Charging status, Battery health
- Shows a **Toast** when battery % changes or charging state changes

---

## Flow

```
Android System
    |
    | sends broadcast: ACTION_BATTERY_CHANGED
    |
    v
BroadcastReceiver (batteryReceiver)
    |
    | reads: level, status, health from intent
    |
    v
Updates TextViews on screen
    +
Shows Toast if something changed
```

---

## Files Used

| File | What it does |
|------|-------------|
| `BroadcastDemo.java` | Registers receiver, reads battery data, updates UI |
| `activity_broadcast_demo.xml` | Shows 3 TextViews for battery info + back button |

---

## Step 1 — Design the Screen

**File:** `activity_broadcast_demo.xml`

```xml
<LinearLayout android:gravity="center" android:orientation="vertical" ...>

    <TextView android:text="🔋 Battery Broadcast Receiver" android:textSize="22sp" />

    <!-- these 3 TextViews will be updated live from Java -->
    <TextView android:id="@+id/txtBatteryLevel"   android:text="Battery Level: --" />
    <TextView android:id="@+id/txtChargingStatus" android:text="Charging Status: --" />
    <TextView android:id="@+id/txtBatteryHealth"  android:text="Battery Health: --" />

    <Button android:id="@+id/btnBackToHome" android:text="Back to Home" />

</LinearLayout>
```

---

## Step 2 — Write BroadcastDemo.java

### 2.1 — Declare the BroadcastReceiver

```java
BroadcastReceiver batteryReceiver = new BroadcastReceiver() {
    @Override
    public void onReceive(Context context, Intent intent) {

        // level = current charge, scale = max charge (mostly 100)
        int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        int batteryPct = (level * 100) / scale;

        // is phone charging right now?
        int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        boolean isCharging = (status == BatteryManager.BATTERY_STATUS_CHARGING);

        // how is the battery condition
        int health = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, -1);
        String healthStatus;
        if (health == BatteryManager.BATTERY_HEALTH_GOOD) {
            healthStatus = "Good ✅";
        } else if (health == BatteryManager.BATTERY_HEALTH_OVERHEAT) {
            healthStatus = "Overheat 🔥";
        } else {
            healthStatus = "Unknown..?";
        }

        // update screen with latest values
        txtBatteryLevel.setText("Battery Level: " + batteryPct + "%");
        txtChargingStatus.setText("Charging Status: " + (isCharging ? "Charging ⚡" : "Discharging 🔋"));
        txtBatteryHealth.setText("Battery Health: " + healthStatus);
    }
};
```

### 2.2 — Register the Receiver in onCreate()

```java
// register receiver — Android will call onReceive() automatically when battery changes
registerReceiver(batteryReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
```

- `registerReceiver` = tell Android: "hey, call my receiver when this event happens"
- `IntentFilter` = which broadcast to listen to

### 2.3 — Unregister in onDestroy()

```java
@Override
protected void onDestroy() {
    super.onDestroy();
    // unregister when screen closes — very important, avoids memory leak
    unregisterReceiver(batteryReceiver);
}
```

> Always unregister! If you don't, Android keeps calling your receiver even after the screen is closed — this wastes memory.

---

## Complete Code — BroadcastDemo.java

```java
public class BroadcastDemo extends AppCompatActivity {

    TextView txtBatteryLevel, txtChargingStatus, txtBatteryHealth;

    int lastBatteryPct = -1;
    boolean lastIsCharging = false;

    BroadcastReceiver batteryReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            int batteryPct = (level * 100) / scale;

            int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            boolean isCharging = (status == BatteryManager.BATTERY_STATUS_CHARGING);

            int health = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, -1);
            String healthStatus;
            if (health == BatteryManager.BATTERY_HEALTH_GOOD) {
                healthStatus = "Good ✅";
            } else if (health == BatteryManager.BATTERY_HEALTH_OVERHEAT) {
                healthStatus = "Overheat 🔥";
            } else {
                healthStatus = "Unknown..?";
            }

            txtBatteryLevel.setText("Battery Level: " + batteryPct + "%");
            txtChargingStatus.setText("Charging Status: " + (isCharging ? "Charging ⚡" : "Discharging 🔋"));
            txtBatteryHealth.setText("Battery Health: " + healthStatus);

            // toast only if battery % changed
            if (batteryPct != lastBatteryPct) {
                Toast.makeText(context, "Battery: " + batteryPct + "%", Toast.LENGTH_SHORT).show();
                lastBatteryPct = batteryPct;
            }

            // toast only if charging state changed
            if (isCharging != lastIsCharging) {
                Toast.makeText(context, isCharging ? "Charging ⚡" : "Discharging 🔋", Toast.LENGTH_SHORT).show();
                lastIsCharging = isCharging;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_broadcast_demo);

        txtBatteryLevel   = findViewById(R.id.txtBatteryLevel);
        txtChargingStatus = findViewById(R.id.txtChargingStatus);
        txtBatteryHealth  = findViewById(R.id.txtBatteryHealth);

        registerReceiver(batteryReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));

        findViewById(R.id.btnBackToHome).setOnClickListener(view -> {
            startActivity(new Intent(BroadcastDemo.this, MainActivity.class));
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(batteryReceiver); // always unregister!
    }
}
```

---

## Register vs Unregister — Simple Analogy

| | What it means |
|---|---|
| `registerReceiver()` | Subscribe to a YouTube channel — you get notified |
| `unregisterReceiver()` | Unsubscribe — stop getting notifications |
| Forget to unregister | App keeps getting notifications even when closed = memory leak ❌ |

---

## Quick Summary

### Fragment

| What | Why |
|------|-----|
| `Fragment` | A piece of screen that can be swapped |
| `FrameLayout` | Empty container where fragment is placed |
| `inflater.inflate()` | Loads XML layout for the fragment |
| `view.findViewById()` | Finds views inside the fragment's own layout |
| `ft.replace()` | Swaps old fragment with new one |
| `ft.commit()` | Applies the swap |

### Broadcast Receiver

| What | Why |
|------|-----|
| `BroadcastReceiver` | Listens to system events |
| `onReceive()` | Called automatically when event happens |
| `IntentFilter` | Tells which broadcast to listen to |
| `registerReceiver()` | Start listening |
| `unregisterReceiver()` | Stop listening (do this in onDestroy) |
| `intent.getIntExtra()` | Read data from the broadcast |

---

## Final Output

**Fragment Demo:**
1. Open app → click **Fragment Demo**
2. Red screen appears by default
3. Click **Show Blue** → Blue screen appears
4. Click **Show Red** → Red screen appears back
5. No new screen opens — just the fragment swaps!

**Broadcast Receiver Demo:**
1. Open app → click **Broadcast Receiver Demo**
2. Battery %, charging status, health shown live
3. Plug/unplug charger → Toast appears instantly
4. Go back → receiver is unregistered automatically
