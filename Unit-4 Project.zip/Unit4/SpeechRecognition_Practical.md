# Speech Recognition - Android Practical Guide

## What is Speech Recognition?
Speech Recognition is a built-in Android feature that **listens to your voice and converts it into text**.  
Android provides a class called `SpeechRecognizer` to do this — no extra library needed.

---

## Tools Required
- Android Studio
- Android Device (real phone recommended — emulator mic may not work properly)
- Minimum SDK: API 24+

---

## Step 1 — Create a New Activity

1. Right click on your package → New → Activity → Empty Activity
2. Name it `SpeechRecognitionDemo`
3. This will create two files:
   - `SpeechRecognitionDemo.java` → Java logic file
   - `activity_speech_recognition_demo.xml` → Layout/UI file

---

## Step 2 — Add Permission in Manifest

Speech Recognition needs **microphone access**, so we must add permission in `AndroidManifest.xml`.

```xml
<uses-permission android:name="android.permission.RECORD_AUDIO" />
```

> Add this line **above** the `<application>` tag.

### Full `AndroidManifest.xml` entry:

```xml
<uses-permission android:name="android.permission.RECORD_AUDIO" />

<application ...>
    <activity
        android:name=".SpeechRecognitionDemo"
        android:exported="false" />
</application>
```

---

## Step 3 — Design the Layout (XML File)

Open `res/layout/activity_speech_recognition_demo.xml` and write:

```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:gravity="center"
    android:orientation="vertical"
    tools:context=".SpeechRecognitionDemo">

    <!-- Shows the recognized speech text -->
    <TextView
        android:id="@+id/txtSpeakOutputText"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginHorizontal="20dp"
        android:text="Your Text Here..."
        android:textAlignment="center"
        android:textSize="25sp" />

    <!-- Mic image — click to start listening -->
    <ImageView
        android:id="@+id/ivMicSpeak"
        android:layout_width="60dp"
        android:layout_height="60dp"
        android:layout_marginTop="20dp"
        android:src="@drawable/mic_img" />

</LinearLayout>
```

### UI Elements Used:
| ID | Type | Purpose |
|---|---|---|
| `txtSpeakOutputText` | TextView | Displays the recognized speech text |
| `ivMicSpeak` | ImageView | Click to start listening |

---

## Step 4 — Write the Java Code

Open `SpeechRecognitionDemo.java` and write:

```java
package com.example.unit4;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class SpeechRecognitionDemo extends AppCompatActivity {

    TextView txtSpeakOutputText;
    ImageView ivMicSpeak;
    SpeechRecognizer speechRecognizer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_speech_recognition_demo);

        txtSpeakOutputText = findViewById(R.id.txtSpeakOutputText);
        ivMicSpeak = findViewById(R.id.ivMicSpeak);

        // Ask RECORD_AUDIO permission if not granted
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.RECORD_AUDIO}, 1);
        }

        // Create SpeechRecognizer object
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);

        // Set listener to handle speech recognition events
        speechRecognizer.setRecognitionListener(new RecognitionListener() {

            @Override
            public void onReadyForSpeech(Bundle params) {
                // Called when mic is ready to listen
                txtSpeakOutputText.setText("Listening...");
                // Change mic color to blue while listening
                ivMicSpeak.setColorFilter(getResources().getColor(android.R.color.holo_blue_dark));
            }

            @Override
            public void onResults(Bundle results) {
                // Called when speech is recognized successfully
                // Results come as a list of possible words
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);

                if (matches != null) {
                    // Show the first (best) result in TextView
                    txtSpeakOutputText.setText(matches.get(0));
                }
                // Reset mic color back to normal after listening
                ivMicSpeak.clearColorFilter();
            }

            @Override
            public void onError(int error) {
                // Called when something goes wrong
                txtSpeakOutputText.setText("Error! Please try again.");
                // Reset mic color back to normal on error
                ivMicSpeak.clearColorFilter();
            }

            // Below methods are required but we don't need them
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() {}
            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}
        });

        // When mic image is clicked, start listening
        ivMicSpeak.setOnClickListener(v -> {

            // Intent tells the SpeechRecognizer what language to use
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);

            // Start listening
            speechRecognizer.startListening(intent);
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Always destroy SpeechRecognizer when activity closes to free memory
        speechRecognizer.destroy();
    }
}
```

---

## Code Explanation — Line by Line

### Imports
```java
import android.speech.SpeechRecognizer;   // main class for speech recognition
import android.speech.RecognizerIntent;   // used to configure the recognizer
import android.speech.RecognitionListener; // listener to handle recognition events
import java.util.ArrayList;               // to store list of recognized words
```

### Variables
```java
SpeechRecognizer speechRecognizer;  // main object that listens to voice
```

### Creating SpeechRecognizer Object
```java
speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
```
- `this` → refers to the current activity
- This creates the recognizer but does NOT start listening yet

### RecognitionListener — 3 Important Methods

| Method | When it is called |
|---|---|
| `onReadyForSpeech()` | Mic is open and ready to listen |
| `onResults()` | Speech successfully converted to text |
| `onError()` | Something went wrong (no speech, network issue, etc.) |

### onResults() Method
```java
ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
txtSpeakOutputText.setText(matches.get(0));
```
- Android returns a **list** of possible words it heard
- `matches.get(0)` → gets the **best/first** result from the list

### Starting the Listener
```java
Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
speechRecognizer.startListening(intent);
```
- `ACTION_RECOGNIZE_SPEECH` → tells Android we want to recognize speech
- `LANGUAGE_MODEL_FREE_FORM` → normal free talking (not a fixed command)
- `startListening(intent)` → mic opens and starts listening

### Mic Color Change
```java
ivMicSpeak.setColorFilter(...holo_blue_dark);  // turns blue while listening
ivMicSpeak.clearColorFilter();                  // resets to normal color
```

### onDestroy()
```java
speechRecognizer.destroy();
```
- Always called when the activity closes
- Frees the microphone so other apps can use it

---

## Step 5 — Working Flow

```
App Opens
    ↓
onCreate() runs → Layout loads on screen
    ↓
Permission check → asks user to allow microphone access
    ↓
SpeechRecognizer object created → Ready ✅
    ↓
User clicks Mic image
    ↓
startListening() → Mic opens
    ↓
onReadyForSpeech() → TextView shows "Listening..." → Mic turns Blue 🔵
    ↓
User speaks
    ↓
onResults() → Speech converted to text → Displayed in TextView → Mic color resets
```

---

## Step 6 — Run the App

1. Connect your Android phone
2. Click Run ▶ in Android Studio
3. A popup will appear asking for **microphone permission** → tap **Allow**
4. Tap the **mic image**
5. Speak anything
6. Your spoken words will appear as text on the screen

---

## Common Mistakes to Avoid

| Mistake | Fix |
|---|---|
| App crashes on open | Check `findViewById` IDs match the XML layout IDs |
| Nothing happens on mic click | Make sure `RECORD_AUDIO` permission is granted |
| `onError()` always called | Check internet connection — SpeechRecognizer needs internet |
| Mic stays blue forever | Make sure `clearColorFilter()` is called in both `onResults()` and `onError()` |
| Works on phone but not emulator | Use a real phone — emulator mic support is limited |

---

## Difference — Speech Recognition vs Text to Speech

| Speech Recognition | Text to Speech |
|---|---|
| Voice → Text | Text → Voice |
| Uses Microphone | Uses Speaker |
| `SpeechRecognizer` class | `TextToSpeech` class |
| Needs `RECORD_AUDIO` permission | No permission needed |
| Needs internet connection | Works offline |

---

## Summary Table

| File | What you do in it |
|---|---|
| `AndroidManifest.xml` | Add `RECORD_AUDIO` permission + verify activity is registered |
| `activity_speech_recognition_demo.xml` | Design UI — TextView and Mic ImageView |
| `SpeechRecognitionDemo.java` | Write logic — create SpeechRecognizer, handle results, show text |

---

*Practical by: Android Development — Unit 4*
