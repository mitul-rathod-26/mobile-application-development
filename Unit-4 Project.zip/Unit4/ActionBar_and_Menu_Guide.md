# ActionBar and Options Menu in Android — Step by Step Guide

---

## What is an ActionBar?

The **ActionBar** is the top bar you see in almost every Android app.  
It usually shows:
- The **app icon** (on the left)
- The **title** of the screen
- A **subtitle** (optional, shown below the title)
- **Action buttons** (icons on the right side)
- A **3-dot overflow menu** (for extra options that don't fit as icons)

Think of it like the toolbar at the top of a website or desktop app.

---

## Step 0 — Fix the Theme to Show the ActionBar

When you create a new project in Android Studio, the default theme has `NoActionBar` in its name — this **hides the ActionBar completely**. You must remove `NoActionBar` from the theme first, otherwise the ActionBar will never appear on screen no matter what code you write.

### Which file to change?

**File:** `res/values/themes.xml`

You will also find a second copy at `res/values-night/themes.xml` — that is for **dark mode**. Change both files the same way.

### What to change:

**Before (default — ActionBar is hidden):**
```xml
<style name="Base.Theme.Unit4" parent="Theme.Material3.DayNight.NoActionBar">
```

**After (ActionBar is visible):**
```xml
<style name="Base.Theme.Unit4" parent="Theme.Material3.DayNight">
```

Just remove `.NoActionBar` from the end of the parent theme name. That's it!

### Why does this work?

| Theme Name | ActionBar |
|---|---|
| `Theme.Material3.DayNight.NoActionBar` | ActionBar is **hidden** |
| `Theme.Material3.DayNight` | ActionBar is **visible** |

Android themes control the overall look of your app. The `NoActionBar` variant is a pre-built theme that specifically tells Android to not show the ActionBar. By switching to `Theme.Material3.DayNight` (without `NoActionBar`), Android will show the ActionBar automatically on every screen.

### Your `themes.xml` should look like this after the change:

```xml
<resources xmlns:tools="http://schemas.android.com/tools">
    <style name="Base.Theme.Unit4" parent="Theme.Material3.DayNight">
        <!-- Customize your light theme here. -->
    </style>

    <style name="Theme.Unit4" parent="Base.Theme.Unit4" />
</resources>
```

> Do the same change in `res/values-night/themes.xml` so the ActionBar also shows in dark mode.

---

## Project Structure You Need

Before writing code, you need these files:

```
app/
 └── src/
      └── main/
           ├── java/com/example/unit4/
           │    └── MainActivity.java        ← Your Java code
           └── res/
                ├── layout/
                │    └── activity_main.xml   ← Your screen layout
                └── menu/
                     └── main.xml            ← Your menu items  ← NEW FILE
```

The most important new thing here is the `res/menu/main.xml` file — this is where you define what buttons appear in the ActionBar.

---

## Step 1 — Create the Menu XML File

### 1.1 — Create the `menu` Resource Folder

1. In Android Studio, look at the left side panel — this is called the **Project panel**
2. Make sure the dropdown at the top of the panel is set to **Android** view
3. Expand `app` → `res`
4. Right-click on the `res` folder
5. Hover over **New** → click **Android Resource Directory**
6. A dialog box will open:
   - In the **Directory name** field, type: `menu`
   - In the **Resource type** dropdown, select: `menu`
   - Leave everything else as default
7. Click **OK**
8. You will now see a new `menu` folder appear inside `res/`

---

### 1.2 — Create the `main.xml` File Inside the `menu` Folder

1. Right-click on the newly created `menu` folder
2. Hover over **New** → click **Menu Resource File**
3. A dialog box will open:
   - In the **File name** field, type: `main`
   - Android Studio will automatically add `.xml` at the end
4. Click **OK**
5. The file `main.xml` will be created and automatically opened in the editor

> After these steps your folder structure will look like:
> ```
> res/
>  └── menu/
>       └── main.xml   ← created successfully
> ```

---

### 1.3 — Add the Menu Items Code

Now that `main.xml` is open, **delete everything** inside it and paste the following code:

**File:** `res/menu/main.xml`

```xml
<?xml version="1.0" encoding="utf-8"?>
<menu xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto">

    <!-- Search button — shows as icon in ActionBar if there is room -->
    <item
        android:id="@+id/search"
        android:icon="@android:drawable/ic_menu_search"
        android:orderInCategory="100"
        android:title="search"
        app:showAsAction="ifRoom" />

    <!-- Call button — shows as icon in ActionBar if there is room -->
    <item
        android:id="@+id/call"
        android:icon="@android:drawable/ic_menu_call"
        android:orderInCategory="100"
        android:title="call"
        app:showAsAction="ifRoom" />

    <!-- Copy — hidden inside the 3-dot overflow menu (never shows as icon) -->
    <item
        android:id="@+id/copy"
        android:orderInCategory="100"
        android:title="copy"
        app:showAsAction="never" />

</menu>
```

### Understanding Each Attribute:

| Attribute | What it does |
|---|---|
| `android:id` | A unique ID so Java code can identify which button was clicked |
| `android:icon` | The icon image shown in the ActionBar |
| `android:title` | The text label (shown in overflow menu or as tooltip) |
| `android:orderInCategory` | Controls the order of items (lower number = appears first) |
| `app:showAsAction` | Controls WHERE the item appears (see below) |

### `showAsAction` Values Explained:

---

**1. `ifRoom`**
- Show the item as an icon in the ActionBar **only if there is enough space**
- If there is no space → it automatically moves to the 3-dot overflow menu
- Most commonly used value

```
Enough space  →  [icon visible in ActionBar]
No space      →  [goes into 3-dot menu]
```

---

**2. `always`**
- **Always** show the item as an icon in the ActionBar no matter what
- Even if there is no space, it will still force itself into the ActionBar
- Avoid using too many `always` items — they can overlap and look bad on small screens

```
Always  →  [icon always visible in ActionBar]
```

---

**3. `never`**
- **Never** show as icon in ActionBar
- Always goes into the 3-dot overflow menu as text only
- Used for less important actions like Settings, Logout, Copy etc.

```
Always  →  [goes into 3-dot menu as text only]
```

---

**4. `withText`**
- Show **both the icon and the text label** together in the ActionBar
- Normally ActionBar shows only the icon, this forces the text to appear next to it
- Usually combined with `ifRoom` like this: `ifRoom|withText`

```
Normal ifRoom  →  [icon only]
withText       →  [icon + label text]
```

---

**5. `collapseActionView`**
- The item stays **hidden/collapsed** as just an icon
- When user taps the icon, it **expands** into a full view like a search bar
- Best example is Search — tap the search icon → a text input box opens in the ActionBar
- When user presses back → it collapses back to just the icon

```
Before tap  →  [search icon only]
After tap   →  [search icon + full text input box opens]
```

---

**Quick Comparison Table:**

| Value | Where it appears | When to use |
|---|---|---|
| `ifRoom` | ActionBar if space available, else 3-dot | Most normal actions |
| `always` | Always in ActionBar | Very important actions |
| `never` | Always in 3-dot menu | Less important actions |
| `withText` | ActionBar with icon + text | When label is important |
| `collapseActionView` | Expands on tap | Search bar, filter input |

---

In our project:
- `search` and `call` use `ifRoom` → they appear as icons in the top bar
- `copy` uses `never` → it hides inside the 3-dot menu

---

## Step 2 — Write the MainActivity.java

**File:** `MainActivity.java`

```java
package com.example.unit4;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.NonNull;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Step A: Get a reference to the ActionBar
        ActionBar actionBar = getSupportActionBar();

        // Step B: Set the title shown in the ActionBar
        actionBar.setTitle("  MCA");

        // Step C: Set a subtitle shown below the title
        actionBar.setSubtitle("   Sem-3 MCA Class");

        // Step D: Set the app icon shown on the left
        actionBar.setIcon(R.drawable.ic_launcher_foreground);

        // Step E: These two lines are needed to actually DISPLAY the icon
        actionBar.setDisplayUseLogoEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);
    }

    // Step F: This method loads (inflates) your menu XML into the ActionBar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    // Step G: This method handles what happens when user clicks a menu item
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.search) {
            Toast.makeText(this, "Search Clicked", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.call) {
            Toast.makeText(this, "Call Clicked", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.copy) {
            Toast.makeText(this, "Copy Clicked", Toast.LENGTH_SHORT).show();
        }

        return super.onOptionsItemSelected(item);
    }
}
```

---

## Step 3 — How Each Part Works (Detailed Explanation)

---

### Part A: `getSupportActionBar()`

```java
ActionBar actionBar = getSupportActionBar();
```

- `getSupportActionBar()` is a method from `AppCompatActivity`
- It **returns the ActionBar object** of the current screen
- Once you have this object, you can call methods on it to customize it
- We store it in a variable called `actionBar` so we don't have to call `getSupportActionBar()` again and again

---

### Part B & C: Title and Subtitle

```java
actionBar.setTitle("  MCA");
actionBar.setSubtitle("   Sem-3 MCA Class");
```

- `setTitle()` → sets the **big text** in the ActionBar
- `setSubtitle()` → sets **smaller text** shown just below the title
- The extra spaces at the start are just to push the text a little to the right (for visual spacing)

---

### Part D & E: Showing the Icon

```java
actionBar.setIcon(R.drawable.ic_launcher_foreground);
actionBar.setDisplayUseLogoEnabled(true);
actionBar.setDisplayShowHomeEnabled(true);
```

- `setIcon()` → tells which image to use as the icon
- `R.drawable.ic_launcher_foreground` → this refers to the image file stored in `res/drawable/` folder
- `setDisplayUseLogoEnabled(true)` → enables logo/icon display mode
- `setDisplayShowHomeEnabled(true)` → makes the home/icon section visible

Both the last two lines are **required together** to make the icon actually appear.

---

### Part F: `onCreateOptionsMenu()` — Loading the Menu

```java
@Override
public boolean onCreateOptionsMenu(Menu menu) {
    getMenuInflater().inflate(R.menu.main, menu);
    return super.onCreateOptionsMenu(menu);
}
```

- Android automatically calls this method **once** when the Activity starts
- `getMenuInflater()` → gets an object that can read XML menu files
- `.inflate(R.menu.main, menu)` → reads your `res/menu/main.xml` file and adds those items into the ActionBar
- Think of "inflate" like **blowing up a balloon** — it takes the flat XML definition and turns it into real visible buttons
- `return super.onCreateOptionsMenu(menu)` → always call the parent method too

---

### Part G: `onOptionsItemSelected()` — Handling Clicks

```java
@Override
public boolean onOptionsItemSelected(@NonNull MenuItem item) {
    int id = item.getItemId();

    if (id == R.id.search) {
        Toast.makeText(this, "Search Clicked", Toast.LENGTH_SHORT).show();
    } else if (id == R.id.call) {
        Toast.makeText(this, "Call Clicked", Toast.LENGTH_SHORT).show();
    } else if (id == R.id.copy) {
        Toast.makeText(this, "Copy Clicked", Toast.LENGTH_SHORT).show();
    }

    return super.onOptionsItemSelected(item);
}
```

- Android automatically calls this method **every time** the user taps a menu item
- `item.getItemId()` → returns the ID of the button that was clicked (like `R.id.search`)
- We store it in `int id` and then compare using `if-else if`
- `Toast.makeText(...).show()` → shows a small popup message at the bottom of the screen

#### Why `if-else if` instead of `switch`?

In older Android, `R.id` values were `final` (constant), so `switch-case` worked fine.  
In newer Android Gradle Plugin (AGP 8+), `R.id` values are **not final**, so `switch-case` gives a compile error:  
`error: constant expression required`  
Using `if-else if` with `==` comparison works in all versions.

---

### What is Toast?

```java
Toast.makeText(this, "Search Clicked", Toast.LENGTH_SHORT).show();
```

| Part | Meaning |
|---|---|
| `this` | The current Activity (context) |
| `"Search Clicked"` | The message to display |
| `Toast.LENGTH_SHORT` | How long to show it (short = ~2 seconds, long = ~3.5 seconds) |
| `.show()` | Actually displays the toast — without this, nothing appears! |

---

## Step 4 — Complete Flow: What Happens When App Runs

```
App Starts
    ↓
onCreate() runs
    → ActionBar title, subtitle, icon are set
    ↓
onCreateOptionsMenu() runs automatically
    → menu/main.xml is inflated
    → search and call icons appear in ActionBar
    → copy is hidden in 3-dot overflow menu
    ↓
User taps a menu item
    ↓
onOptionsItemSelected() runs automatically
    → item.getItemId() checks which button was tapped
    → matching Toast message is shown
```

---

## Step 5 — How to Run This Practical

1. Open Android Studio and create a new project with **Empty Activity**
2. Make sure your `MainActivity` extends `AppCompatActivity`
3. Open `res/values/themes.xml` and remove `.NoActionBar` from the parent theme name
4. Do the same in `res/values-night/themes.xml`
5. Create the folder `res/menu/` (right-click `res` → New → Android Resource Directory → select `menu`)
6. Create `main.xml` inside `res/menu/` and paste the menu XML code
7. Replace your `MainActivity.java` with the code shown above
8. Click **Run** (green play button) or press `Shift + F10`
9. On the emulator/device, you will see:
   - ActionBar with title "MCA" and subtitle "Sem-3 MCA Class"
   - Search and Call icons on the right side of the ActionBar
   - A 3-dot menu that contains "copy"
10. Tap each button — a Toast message will appear at the bottom

---

## Quick Summary

| Concept | File | Purpose |
|---|---|---|
| Enable ActionBar | `res/values/themes.xml` | Remove `.NoActionBar` from parent theme |
| ActionBar customization | `MainActivity.java` → `onCreate()` | Set title, subtitle, icon |
| Menu items definition | `res/menu/main.xml` | Define what buttons appear |
| Loading menu into ActionBar | `onCreateOptionsMenu()` | Inflate XML into ActionBar |
| Handling button clicks | `onOptionsItemSelected()` | Detect which button was tapped and respond |
| Toast | Inside click handler | Show a small popup message |

---

## Context Menu — Help Page

### What is a Context Menu?

A **Context Menu** appears when the user **long presses** (holds tap for 1-2 seconds) on a view like a TextView or Button. It shows a floating list of options related to that view.

Think of it like a **right-click menu** on a computer.

```
User long presses TextView
           ↓
  ┌─────────────────┐
  │ Choose a color  │
  ├─────────────────┤
  │ Yellow          │
  │ Gray            │
  │ Cyan            │
  └─────────────────┘
```

---

### Layout — `activity_help_page.xml`

```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout
    android:id="@+id/main"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:gravity="center"
    android:orientation="vertical">

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Context Menu Demo"
        android:textSize="25sp"
        android:textStyle="bold" />

    <!-- This TextView will trigger the context menu on long press -->
    <TextView
        android:id="@+id/txtLongPress"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Long press me!"
        android:textSize="18sp"
        android:padding="20dp"
        android:layout_marginTop="50dp" />

</LinearLayout>
```

- The `LinearLayout` has `android:id="@+id/main"` — this is used in Java to change the background color
- The `TextView` with id `txtLongPress` is the view that will trigger the context menu on long press

---

### Java Code — `Help_Page.java`

```java
public class Help_Page extends AppCompatActivity {
    private TextView txtLongPress;
    private LinearLayout linearLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_page);

        txtLongPress = findViewById(R.id.txtLongPress);
        linearLayout = findViewById(R.id.main);

        // Step 1: Register the TextView to show context menu on long press
        registerForContextMenu(txtLongPress);
    }

    // Step 2: Build the context menu items
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.setHeaderTitle("Choose a color");
        menu.add(0, v.getId(), 0, "Yellow");
        menu.add(0, v.getId(), 0, "Gray");
        menu.add(0, v.getId(), 0, "Cyan");
    }

    // Step 3: Handle which item was selected
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        String title = item.getTitle().toString();
        switch (title) {
            case "Yellow":
                linearLayout.setBackgroundColor(Color.YELLOW);
                break;
            case "Gray":
                linearLayout.setBackgroundColor(Color.GRAY);
                break;
            case "Cyan":
                linearLayout.setBackgroundColor(Color.CYAN);
                break;
        }
        return true;
    }
}
```

---

### How Each Part Works:

**`registerForContextMenu(txtLongPress)`**
- This tells Android — *"when user long presses this view, show a context menu"*
- Without this line, long pressing the TextView will do nothing
- You pass the view you want to attach the context menu to

**`onCreateContextMenu()`**
- Android automatically calls this when the user long presses the registered view
- `menu.setHeaderTitle()` → sets the title shown at the top of the context menu
- `menu.add(groupId, itemId, order, title)` → adds each item to the menu
  - `groupId` → group number, use `0` if no grouping needed
  - `itemId` → here `v.getId()` is used which gives the id of the view that was long pressed
  - `order` → display order, use `0` for default
  - `title` → the text shown for that menu item

**`onContextItemSelected()`**
- Android automatically calls this when user taps an item from the context menu
- `item.getTitle().toString()` → gets the text of the tapped item like `"Yellow"`
- Based on the title, the background color of the `LinearLayout` is changed using `setBackgroundColor()`

---

### Complete Flow:

```
User long presses "Long press me!" TextView
           ↓
onCreateContextMenu() called automatically
           ↓
Context menu appears with Yellow, Gray, Cyan options
           ↓
User taps "Yellow"
           ↓
onContextItemSelected() called automatically
           ↓
linearLayout.setBackgroundColor(Color.YELLOW)
           ↓
Background of entire screen changes to Yellow
```

---

## Popup Menu — Settings Page

### What is a Popup Menu?

A **Popup Menu** appears when the user **clicks a Button**. It shows a floating dropdown menu anchored just below (or above) that button.

Unlike Context Menu (long press), Popup Menu is triggered by a **normal single tap** on a button.

```
User taps Button
      ↓
  ┌─────────────┐
  │ search      │
  │ help        │
  │ settings    │
  └─────────────┘
```

---

### Layout — `activity_settings_page.xml`

```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout
    android:id="@+id/main"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:gravity="center"
    android:orientation="vertical">

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Popup Menu Demo"
        android:textSize="25sp"
        android:textStyle="bold" />

    <!-- Clicking this button will show the popup menu -->
    <Button
        android:id="@+id/btnClick"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Click Me"
        android:layout_marginTop="50dp" />

</LinearLayout>
```

- The `Button` with id `btnClick` is what triggers the popup menu when clicked

---

### Java Code — `Settings_Page.java`

```java
public class Settings_Page extends AppCompatActivity {
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings_page);

        button = findViewById(R.id.btnClick);

        // Step 1: Set click listener on the button
        button.setOnClickListener(v -> {

            // Step 2: Create PopupMenu and anchor it to the button
            PopupMenu popupMenu = new PopupMenu(this, button);

            // Step 3: Inflate menu items from main.xml
            popupMenu.getMenuInflater().inflate(R.menu.main, popupMenu.getMenu());

            // Step 4: Handle item click
            popupMenu.setOnMenuItemClickListener(menuItem -> {
                Toast.makeText(this, "You Clicked " + menuItem.getTitle(), Toast.LENGTH_SHORT).show();
                return true;
            });

            // Step 5: Show the popup menu
            popupMenu.show();
        });
    }
}
```

---

### How Each Part Works:

**`new PopupMenu(this, button)`**
- Creates a new PopupMenu object
- First parameter `this` → current Activity context
- Second parameter `button` → the view the popup menu will be **anchored to** (appears just below this view)

**`popupMenu.getMenuInflater().inflate(R.menu.main, popupMenu.getMenu())`**
- Reads the `res/menu/main.xml` file and loads those items into the popup menu
- Same `main.xml` used for ActionBar menu is reused here

**`popupMenu.setOnMenuItemClickListener()`**
- Sets a listener that fires when user taps any item in the popup
- `menuItem.getTitle()` → gets the text of the tapped item
- Toast shows which item was clicked

**`popupMenu.show()`**
- Actually displays the popup menu on screen
- Without this line the popup will never appear

---

### Complete Flow:

```
User taps "Click Me" Button
           ↓
setOnClickListener fires
           ↓
PopupMenu is created and inflated with main.xml items
           ↓
popupMenu.show() displays the menu below the button
           ↓
User taps an item
           ↓
setOnMenuItemClickListener fires
           ↓
Toast shows "You Clicked search / help / settings"
```

---

## Difference Between All 3 Menu Types

| | Options Menu | Context Menu | Popup Menu |
|---|---|---|---|
| How to open | Tap ActionBar icons or 3-dot | Long press on a view | Tap a button |
| Where it appears | In the ActionBar | Floating near the view | Anchored below a button |
| Triggered by | ActionBar | Long press | Button click |
| Defined in | `onCreateOptionsMenu()` | `onCreateContextMenu()` | `PopupMenu` object in Java |
| Used for | App-wide actions | View specific actions | Button specific actions |
