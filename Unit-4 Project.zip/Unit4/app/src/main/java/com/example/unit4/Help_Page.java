package com.example.unit4;

import android.graphics.Color;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class Help_Page extends AppCompatActivity {
    private TextView txtLongPress;
    private LinearLayout linearLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_help_page);

        txtLongPress = findViewById(R.id.txtLongPress);
        linearLayout = findViewById(R.id.main);

        // Register a view for the context menu
        registerForContextMenu(txtLongPress);
    }


    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        menu.setHeaderTitle("Choose a color");
        // Add menu items
        menu.add(0, v.getId(), 0, "Yellow");
        menu.add(0, v.getId(), 0, "Gray");
        menu.add(0, v.getId(), 0, "Cyan");
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        String title = item.getTitle().toString();

        switch (title) {
            case "Yellow":
                linearLayout.setBackgroundColor(Color.YELLOW);
                break;
            case "Gray":
                linearLayout.setBackgroundColor(Color.GRAY);
                break;
            case "Cyan":
                linearLayout.setBackgroundColor(Color.CYAN);
                break;
        }
        return true;
    }
}