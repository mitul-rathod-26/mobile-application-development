package com.example.unit4;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.NonNull;

public class MainActivity extends AppCompatActivity {

    TextView txtDialogBoxDemo, txtNotificationDemo, txtTextToSpeechDemo, txtSpeechRecognitionDemo;

    TextView txtCopyPasteClipboardDemo, txtScreenSizeDensityDemo, txtAnimationsDemo, txtShapeVectoreDemo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // calling this activity's function to
        // use ActionBar utility methods
        ActionBar actionBar = getSupportActionBar();

        if (actionBar != null) {
            // providing title for the ActionBar
            actionBar.setTitle("  MCA");

            // providing subtitle for the ActionBar
            actionBar.setSubtitle("   Sem-3 MCA Class");

            // adding icon in the ActionBar
            actionBar.setIcon(R.drawable.ic_launcher_foreground);

            // methods to display the icon in the ActionBar
            actionBar.setDisplayUseLogoEnabled(true);
            actionBar.setDisplayShowHomeEnabled(true);
        }

        txtDialogBoxDemo = findViewById(R.id.txtDialogBoxDemo);

        txtDialogBoxDemo.setOnClickListener(v -> {

            Intent intent = new Intent(this, DialogBoxDemo.class);
            startActivity(intent);
        });

        /// Navigate to Notification Demo Activity
        txtNotificationDemo = findViewById(R.id.txtNotificationDemo);

        txtNotificationDemo.setOnClickListener(v -> {

            Intent intent = new Intent(this, NotificationsDemo.class);
            startActivity(intent);
        });

        /// Navigate to Text To Speech Demo Activity
        txtTextToSpeechDemo = findViewById(R.id.txtTextToSpeechDemo);

        txtTextToSpeechDemo.setOnClickListener(v -> {
            Intent intent = new Intent(this, TextToSpeechDemo.class);
            startActivity(intent);
        });

        /// Navigate to Speech Recognition Demo Activity
        txtSpeechRecognitionDemo = findViewById(R.id.txtSpeechRecognitionDemo);

        txtSpeechRecognitionDemo.setOnClickListener(v -> {
            Intent intent = new Intent(this, SpeechRecognitionDemo.class);
            startActivity(intent);
        });

        /// Navigate to Screen Size & Density Demo Activity
        txtScreenSizeDensityDemo = findViewById(R.id.txtScreenSizeDensityDemo);

        txtScreenSizeDensityDemo.setOnClickListener(v -> {
            Intent intent = new Intent(this, ScreenSize_Density_Demo.class);
            startActivity(intent);
        });

        /// Navigate to Copy, Paste & Clipboard Demo Activity
        txtCopyPasteClipboardDemo = findViewById(R.id.txtCopyPasteClipboardDemo);

        txtCopyPasteClipboardDemo.setOnClickListener(v -> {
            Intent intent = new Intent(this, CopyPasteClipboardDemo.class);
            startActivity(intent);
        });

        /// Navigate to Animations Demo Activity
        txtAnimationsDemo = findViewById(R.id.txtAnimationsDemo);

        txtAnimationsDemo.setOnClickListener(v -> {
            Intent intent = new Intent(this, AnimationsDemo.class);
            startActivity(intent);
        });

        /// Navigate to Shape & Vector Demo Activity
        txtShapeVectoreDemo = findViewById(R.id.txtShapeVectoreDemo);

        txtShapeVectoreDemo.setOnClickListener(v -> {
            Intent intent = new Intent(this, ShapeVectorDemo.class);
            startActivity(intent);
        });

    }


    // method to inflate the options menu when
    // the user opens the menu for the first time
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    // methods to control the operations that will
    // happen when user clicks on the action buttons

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id = item.getItemId();
        if (id == R.id.search) {
            Toast.makeText(this, "Search Clicked", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.help) {
            Toast.makeText(this, "Help Clicked", Toast.LENGTH_SHORT).show();

            // navigating to help activity
            Intent intent = new Intent(this, Help_Page.class);
            startActivity(intent);

        } else if (id == R.id.settings) {
            Toast.makeText(this, "Settings Clicked", Toast.LENGTH_SHORT).show();

            // navigating to settings activity
            Intent intent = new Intent(this, Settings_Page.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
}