package com.example.unit4;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class ShapeVectorDemo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shape_vector_demo);
    }
}
