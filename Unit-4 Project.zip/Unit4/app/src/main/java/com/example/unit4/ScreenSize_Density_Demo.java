package com.example.unit4;

import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ScreenSize_Density_Demo extends AppCompatActivity {

    Button btnVibrate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_screen_size_density_demo);

        btnVibrate = findViewById(R.id.btnVibrate);

        /// Vibrate on button click
        btnVibrate.setOnClickListener(view -> {
            Vibrator click = (Vibrator) getSystemService(VIBRATOR_SERVICE);

            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
                click.vibrate(VibrationEffect.createOneShot(900, VibrationEffect.DEFAULT_AMPLITUDE));
                Toast.makeText(this, "Vibration...!!", Toast.LENGTH_SHORT).show();
            }else{
                // 100 milliseconds = 0.1 seconds & 1 seconds = 1000 milliseconds
                click.vibrate(300);
            }
        });

    }
}