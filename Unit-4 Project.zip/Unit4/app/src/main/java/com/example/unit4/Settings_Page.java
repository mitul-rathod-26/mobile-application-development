package com.example.unit4;

import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.PopupMenu;
import android.widget.Toast;

public class Settings_Page extends AppCompatActivity {
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_settings_page);

        button = findViewById(R.id.btnClick);

        button.setOnClickListener(v -> {
            /// Initializing the popup menu and giving the reference as current context
            PopupMenu popupMenu = new PopupMenu(this, button);

            /// Inflating popup menu from popup_menu.xml file
            popupMenu.getMenuInflater().inflate(R.menu.main, popupMenu.getMenu());

            /// Handling menu item click events
            popupMenu.setOnMenuItemClickListener(menuItem -> {
                Toast.makeText(this, "You Clicked " + menuItem.getTitle(), Toast.LENGTH_SHORT).show();
                return true;
            });

            /// Showing the popup menu
            popupMenu.show();
        });
    }
}