package com.example.unit4;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

public class NotificationsDemo extends AppCompatActivity {

    Button btnSendNotification;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications_demo);

        /// So we check if permission is already given or not
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {

            /// Check if permission is NOT granted
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {

                /// Ask the user to allow notification permission (shows a popup)
                ActivityCompat.requestPermissions(this,
                        new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 1);
            }
        }

        btnSendNotification = findViewById(R.id.btnSendNotification);

        /// call showNotification() method
        btnSendNotification.setOnClickListener(v -> {
            showNotification();

            /// Toast - shows a small popup message at the bottom of the screen
            Toast.makeText(this, "Notification Sent!", Toast.LENGTH_LONG).show();
        });
    }

    void showNotification() {

        /// channelId is a unique name for our notification channel
        String channelId = "my_channel";

        /// NotificationManager is responsible for showing notifications
        NotificationManager manager = getSystemService(NotificationManager.class);

        /// NotificationChannel is required from Android 8 (API 26) and above
        /// On Android 7 or below, this code will be skipped (to avoid crash)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            /// Create a channel with an ID, name, and importance level
            NotificationChannel channel = new NotificationChannel(
                    channelId,               // unique ID for the channel
                    "My Notifications",      // name shown in phone settings
                    NotificationManager.IMPORTANCE_DEFAULT  // normal priority
            );

            /// Register the channel with the system
            manager.createNotificationChannel(channel);
        }

        /// Build the notification (set icon, title, message)
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, channelId)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Hello!")
                .setContentText("This is your first notification.")
                .setAutoCancel(true);  // notification disappears when user taps it

        /// Show the notification, 1 is the notification ID (use different IDs for different notifications)
        manager.notify(1, builder.build());
    }
}
