package com.example.unit4;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class SpeechRecognitionDemo extends AppCompatActivity {

    TextView txtSpeakOutputText;
    ImageView ivMicSpeak;

    SpeechRecognizer speechRecognizer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_speech_recognition_demo);

        txtSpeakOutputText = findViewById(R.id.txtSpeakOutputText);
        ivMicSpeak = findViewById(R.id.ivMicSpeak);

        // Ask RECORD_AUDIO permission if not granted
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.RECORD_AUDIO}, 1);
        }

        // Create SpeechRecognizer object
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);

        // Set listener to handle speech recognition events
        speechRecognizer.setRecognitionListener(new RecognitionListener() {

            @Override
            public void onReadyForSpeech(Bundle params) {
                /// Called when mic is ready to listen
                txtSpeakOutputText.setText("Listening...");
                /// Change mic color to blue while listening
                ivMicSpeak.setColorFilter(getResources().getColor(android.R.color.holo_blue_dark));
            }

            @Override
            public void onBeginningOfSpeech() {

            }

            @Override
            public void onRmsChanged(float v) {

            }

            @Override
            public void onBufferReceived(byte[] bytes) {

            }

            @Override
            public void onEndOfSpeech() {

            }

            @Override
            public void onResults(Bundle results) {
                // Called when speech is recognized successfully
                // Results come as a list of possible words
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);

                if (matches != null) {
                    // Show the first (best) result in TextView
                    txtSpeakOutputText.setText(matches.get(0));
                    Log.d("Result is ==>> ", matches.get(0));
                }
                // Reset mic color back to normal after listening
                ivMicSpeak.clearColorFilter();
            }

            @Override
            public void onPartialResults(Bundle bundle) {

            }

            @Override
            public void onEvent(int i, Bundle bundle) {

            }

            @Override
            public void onError(int error) {
                // Called when something goes wrong
                txtSpeakOutputText.setText("Error! Please try again.");
                // Reset mic color back to normal on error
                ivMicSpeak.clearColorFilter();
            }


        });

        // When mic image is clicked, start listening
        ivMicSpeak.setOnClickListener(v -> {

            // Intent tells the SpeechRecognizer what language to use
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);

            // Start listening
            speechRecognizer.startListening(intent);
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Always destroy SpeechRecognizer when activity closes to free memory
        speechRecognizer.destroy();
    }
}
