package com.example.unit4;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AlertDialog;


public class DialogBoxDemo extends AppCompatActivity {

    Button btnBack, btnShowCustomDialog;

    AlertDialog.Builder builder;

    TextView okay_text, cancel_text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_dialog_box_demo);

        btnBack = findViewById(R.id.btnBack);

        btnBack.setOnClickListener(v -> {

            /// Create the object of AlertDialog Builder class
            builder = new AlertDialog.Builder(DialogBoxDemo.this);

            /// Set the message show for the Alert time
            builder.setMessage("Do you want to exit ?");

            /// Set Alert Title
            builder.setTitle("Alert !");

            builder.setCancelable(false);

            /// Exit if click yes
            builder.setPositiveButton("Ok", (DialogInterface.OnClickListener) (dialog, which) -> {
                finish();
                Toast.makeText(DialogBoxDemo.this, "Exit, navigate to home screen", Toast.LENGTH_SHORT).show();
            });

           /// Cancel the dialog
            builder.setNegativeButton("No", (DialogInterface.OnClickListener) (dialog, which) -> {
                /// If user click no then dialog box is canceled.
                dialog.cancel();
                Toast.makeText(DialogBoxDemo.this, "You clicked no", Toast.LENGTH_SHORT).show();
            });

            /// Create the Alert dialog
            AlertDialog alertDialog = builder.create();

            /// Show the Alert Dialog box
            alertDialog.show();
        });


        /// Show Custom Dialog
        Dialog dialog = new Dialog(DialogBoxDemo.this);

        btnShowCustomDialog = findViewById(R.id.btnShowCustomDialog);
        btnShowCustomDialog.setOnClickListener(v -> {
            dialog.setContentView(R.layout.activity_show_custom_dialog);

            /// Set the custom dialog size
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            dialog.setCancelable(false);

            /// Initialize the custom dialog elements - TextView
            okay_text = dialog.findViewById(R.id.okay_text);
            cancel_text = dialog.findViewById(R.id.cancel_text);

            /// Ok Button
            okay_text.setOnClickListener(v1 -> {
                dialog.dismiss();
                Toast.makeText(this, "Okay clicked", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
            });

            /// Cancel Button
            cancel_text.setOnClickListener(v1 -> {
                dialog.dismiss();
                Toast.makeText(this, "Cancel clicked", Toast.LENGTH_SHORT).show();
            });

            dialog.show();

        });

        /// Type of the dialogs ===>>> 1. AlertDialog → 2. Custom Dialog → 3. DatePickerDialog → 4. TimePickerDialog

    }
}