package com.example.unit4;

import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class TextToSpeechDemo extends AppCompatActivity {
    EditText edtText;
    Button btnText;
    TextView textView;
    TextToSpeech textToSpeech;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_text_to_speech_demo);

        edtText = findViewById(R.id.edtText);
        btnText = findViewById(R.id.btnText);
        textView = findViewById(R.id.textView);

        // create an object textToSpeech and adding features into it
        textToSpeech = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int i) {

                // if No error is found then only it will run
                if(i!=TextToSpeech.ERROR){
                    // To Choose language of speech
                    textToSpeech.setLanguage(Locale.US);
                }
            }
        });

        btnText.setOnClickListener(view -> {
            // To Convert Text to Speech
            String toSpeak = edtText.getText().toString();
            textView.setText(toSpeak);
            textToSpeech.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, null);

            /// QUEUE_FLUSH means — "stop whatever you're saying right now and say this new text"
            /// QUEUE_ADD means - "which would wait and add to the queue"
        });
    }
}