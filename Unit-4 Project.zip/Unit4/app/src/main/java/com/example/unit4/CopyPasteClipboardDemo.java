package com.example.unit4;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class CopyPasteClipboardDemo extends AppCompatActivity {

    EditText edtInput;
    Button btnCopy, btnPaste, btnClipboard;
    TextView txtShowText;
    ClipboardManager clipboardManager;
    ArrayList<String> clipboardHistory = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_copy_paste_clipboard_demo);

        edtInput = findViewById(R.id.edtInput);
        btnCopy = findViewById(R.id.btnCopy);
        btnPaste = findViewById(R.id.btnPaste);
        btnClipboard = findViewById(R.id.btnClipboard);
        txtShowText = findViewById(R.id.txtShowText);

        /// Initialize the clipboard manager
        clipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);

        /// Copy Text to Clipboard
        btnCopy.setOnClickListener(view -> {
            String inputText = edtInput.getText().toString();
            if (!inputText.isEmpty()) {
                ClipData data = ClipData.newPlainText("data", inputText);
                clipboardManager.setPrimaryClip(data);
                clipboardHistory.add(inputText);
                Toast.makeText(this, "Text Copied...", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Please enter some text...", Toast.LENGTH_SHORT).show();
            }
        });

        /// Paste Text from Clipboard
        btnPaste.setOnClickListener(view -> {
            ClipData.Item item = clipboardManager.getPrimaryClip().getItemAt(0);
            String showText = item.getText().toString();

            if (!showText.isEmpty()) {
                txtShowText.setText(showText);
                Toast.makeText(this, "Text Pasted...", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "No text copied...", Toast.LENGTH_SHORT).show();
            }
        });

        /// Show Clipboard History
        btnClipboard.setOnClickListener(view -> {
            if (clipboardHistory.isEmpty()) {
                Toast.makeText(this, "Clipboard is empty...", Toast.LENGTH_SHORT).show();
                return;
            }

            String[] items = clipboardHistory.toArray(new String[0]);

            new AlertDialog.Builder(this)
                    .setTitle("Clipboard")
                    .setItems(items, (dialog, which) -> {
                        txtShowText.setText(items[which]);
                        Toast.makeText(this, "Text Selected...", Toast.LENGTH_SHORT).show();
                    })
                    .show();
        });
    }
}