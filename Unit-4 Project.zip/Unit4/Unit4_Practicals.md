# Unit 4 - Android Practicals

### Practicals Covered
1. Designing for Every Screen Size and Density
2. Controlling Device Vibration
3. Copy, Paste and the Clipboard

---

---

# Practical 1 — Designing for Every Screen Size and Density

## What is it?
Android runs on thousands of different devices — phones, tablets, foldables — each with different screen sizes and pixel densities. This practical teaches how to make your app look good on ALL of them using `dimens.xml` and resource folders.

## Key Concepts

### dp (density-independent pixels)
- Always use `dp` for margins, padding, sizes — never use `px`
- `dp` automatically scales based on screen density

### sp (scale-independent pixels)
- Always use `sp` for text sizes
- Same as `dp` but also respects user's font size setting

### sw (Smallest Width)
- Checks the **shortest side** of the screen
- Does **NOT change** when device is rotated
- Used to target device type (phone vs tablet)

### w (Available Width)
- Checks the **current width** at that moment
- **Changes** when device is rotated
- Used to target landscape mode on wide screens

---

## Step 1 — Create the Activity

Create a new Empty Activity named `ScreenSize_Density_Demo`.

---

## Step 2 — Create dimens.xml folders

You need to create **3 folders** inside `res/` with exact naming:

```
res/values/              → default (small phones)
res/values-sw480dp/      → medium phones (shortest side >= 480dp)
res/values-w820dp/       → wide/landscape screens (current width >= 820dp)
```

> **Important:** The folder name is mandatory. Android reads the folder name to decide which one to use. Wrong name = Android ignores it and uses default.

| Folder | For | Rotation changes it? |
|---|---|---|
| `values/` | All devices (default) | — |
| `values-sw480dp/` | Medium phones & tablets | ❌ No |
| `values-w820dp/` | Wide screens / Landscape | ✅ Yes |

---

## Step 3 — Create dimens.xml in each folder

Create a file named `dimens.xml` inside **each** of the 3 folders.

### res/values/dimens.xml (Small phones — default)
```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>

    <!-- dim_1 to dim_100 — use for margins, padding, sizes -->
    <dimen name="dim_1">1dp</dimen>
    <dimen name="dim_2">2dp</dimen>
    <dimen name="dim_3">3dp</dimen>
    <!-- ... continue till dim_100 → each value = number dp -->
    <dimen name="dim_100">100dp</dimen>

    <!-- Minus — used for negative margin (overlapping views) -->
    <dimen name="minus">-45dp</dimen>

    <!-- font_size_10 to font_size_60 — use for text sizes -->
    <dimen name="font_size_10">10sp</dimen>
    <dimen name="font_size_11">11sp</dimen>
    <!-- ... continue till font_size_60 → each value = number sp -->
    <dimen name="font_size_60">60sp</dimen>

</resources>
```

### res/values-sw480dp/dimens.xml (Medium phones — 1.5x scale)
```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>

    <!-- dim values are 1.5x of default -->
    <dimen name="dim_1">1.5dp</dimen>
    <dimen name="dim_2">3dp</dimen>
    <!-- ... each value = number * 1.5 dp -->
    <dimen name="dim_100">150dp</dimen>

    <dimen name="minus">-67.5dp</dimen>

    <!-- font sizes are 1.5x of default -->
    <dimen name="font_size_10">15sp</dimen>
    <!-- ... each value = number * 1.5 sp -->
    <dimen name="font_size_60">90sp</dimen>

</resources>
```

### res/values-w820dp/dimens.xml (Wide screens — 2x scale)
```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>

    <!-- dim values are 2x of default -->
    <dimen name="dim_1">2dp</dimen>
    <dimen name="dim_2">4dp</dimen>
    <!-- ... each value = number * 2 dp -->
    <dimen name="dim_100">200dp</dimen>

    <dimen name="minus">-90dp</dimen>

    <!-- font sizes are 2x of default -->
    <dimen name="font_size_10">20sp</dimen>
    <!-- ... each value = number * 2 sp -->
    <dimen name="font_size_60">120sp</dimen>

</resources>
```

> **How it works:** All 3 files have the **same names** (`dim_1`, `font_size_10`, etc.) but **different values**. Android automatically picks the right file based on the device screen size.

---

## Step 4 — Use dimens in Layout (activity_screen_size_density_demo.xml)

```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    android:id="@+id/main"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:padding="@dimen/dim_16"
    tools:context=".ScreenSize_Density_Demo">

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Screen Size Demo"
        android:textSize="@dimen/font_size_22"
        android:layout_marginTop="@dimen/dim_30"
        android:layout_gravity="center" />

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="This text uses font_size_16"
        android:textSize="@dimen/font_size_16"
        android:layout_marginTop="@dimen/dim_20" />

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="This text uses font_size_20"
        android:textSize="@dimen/font_size_20"
        android:layout_marginTop="@dimen/dim_20" />

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="This text uses font_size_28"
        android:textSize="@dimen/font_size_28"
        android:layout_marginTop="@dimen/dim_20" />

</LinearLayout>
```

> Instead of writing `android:textSize="22sp"` directly, you write `android:textSize="@dimen/font_size_22"` — Android picks the right value from the right folder automatically. No Java code needed!

---

---

# Practical 2 — Controlling Device Vibration

## What is it?
This practical teaches how to make the device vibrate using the `Vibrator` system service. Since `VibrationEffect` was introduced in API 26 (Android 8.0), we need to handle both old and new devices.

## Key Concepts

| | New Way (API 26+) | Old Way (API 25 and below) |
|---|---|---|
| Method | `VibrationEffect.createOneShot()` | `vibrate(milliseconds)` |
| Android | 8.0 and above | 7.1 and below |

> **Note:** 1 second = 1000 milliseconds. So `100` = 0.1 seconds vibration.

---

## Step 1 — Add Permission in AndroidManifest.xml

Without this permission vibration will NOT work on real device.

```xml
<uses-permission android:name="android.permission.VIBRATE" />
```

Add it before the `<application>` tag:

```xml
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.VIBRATE" />

    <application ... >
        ...
    </application>

</manifest>
```

---

## Step 2 — Add Button in Layout (activity_screen_size_density_demo.xml)

```xml
<Button
    android:id="@+id/btnVibrate"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content"
    android:layout_gravity="center"
    android:layout_marginTop="@dimen/dim_20"
    android:text="Click to Vibrate" />
```

---

## Step 3 — Java Code (ScreenSize_Density_Demo.java)

```java
package com.example.unit4;

import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ScreenSize_Density_Demo extends AppCompatActivity {

    Button btnVibrate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen_size_density_demo);

        btnVibrate = findViewById(R.id.btnVibrate);

        btnVibrate.setOnClickListener(view -> {
            Vibrator click = (Vibrator) getSystemService(VIBRATOR_SERVICE);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                // API 26+ (Android 8.0 and above) — New way
                click.vibrate(VibrationEffect.createOneShot(100, VibrationEffect.DEFAULT_AMPLITUDE));
                Toast.makeText(this, "Vibration...!!", Toast.LENGTH_SHORT).show();
            } else {
                // API 25 and below (Android 7.1 and older) — Old way
                // 100 milliseconds = 0.1 seconds & 1 second = 1000 milliseconds
                click.vibrate(300);
            }
        });
    }
}
```

## How it works step by step
1. User clicks `btnVibrate`
2. `Vibrator` service is fetched using `getSystemService(VIBRATOR_SERVICE)`
3. `Build.VERSION.SDK_INT` checks the Android version of the device
4. If API 26 or above → uses `VibrationEffect.createOneShot(100, DEFAULT_AMPLITUDE)` → vibrates for 100ms
5. If API 25 or below → uses old `vibrate(300)` → vibrates for 300ms
6. Toast message is shown

---

---

# Practical 3 — Copy, Paste and the Clipboard

## What is it?
This practical teaches how to copy text to the system clipboard, paste it back, and maintain a clipboard history within the app using `ClipboardManager`.

## Key Classes

| Class | Purpose |
|---|---|
| `ClipboardManager` | System service to manage clipboard |
| `ClipData` | Holds the actual data being copied |
| `ClipData.Item` | Single item inside ClipData |
| `ArrayList<String>` | Stores clipboard history in the app |
| `AlertDialog` | Shows clipboard history as a list |

---

## Step 1 — Create the Activity

Create a new Empty Activity named `CopyPasteClipboardDemo`.

---

## Step 2 — Layout (activity_copy_paste_clipboard_demo.xml)

```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    android:id="@+id/main"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    tools:context=".CopyPasteClipboardDemo">

    <EditText
        android:id="@+id/edtInput"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="150dp"
        android:layout_marginStart="20dp"
        android:layout_marginEnd="20dp"
        android:hint="Write Something..." />

    <LinearLayout
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:orientation="horizontal"
        android:layout_marginTop="20dp"
        android:layout_marginStart="20dp"
        android:layout_marginEnd="20dp">

        <Button
            android:id="@+id/btnCopy"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Copy"
            android:textStyle="bold"
            android:textSize="16sp" />

        <Button
            android:id="@+id/btnPaste"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Paste"
            android:textStyle="bold"
            android:textSize="16sp"
            android:layout_marginStart="15dp" />

        <Button
            android:id="@+id/btnClipboard"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Clipboard"
            android:textStyle="bold"
            android:textSize="16sp"
            android:layout_marginStart="15dp" />

    </LinearLayout>

    <TextView
        android:id="@+id/txtShowText"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Copied Text Here..."
        android:textSize="22sp"
        android:textColor="#F44336"
        android:layout_marginTop="80dp"
        android:layout_gravity="center" />

</LinearLayout>
```

---

## Step 3 — Java Code (CopyPasteClipboardDemo.java)

```java
package com.example.unit4;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class CopyPasteClipboardDemo extends AppCompatActivity {

    EditText edtInput;
    Button btnCopy, btnPaste, btnClipboard;
    TextView txtShowText;
    ClipboardManager clipboardManager;
    ArrayList<String> clipboardHistory = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_copy_paste_clipboard_demo);

        edtInput = findViewById(R.id.edtInput);
        btnCopy = findViewById(R.id.btnCopy);
        btnPaste = findViewById(R.id.btnPaste);
        btnClipboard = findViewById(R.id.btnClipboard);
        txtShowText = findViewById(R.id.txtShowText);

        clipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);

        // Copy Text to Clipboard
        btnCopy.setOnClickListener(view -> {
            String inputText = edtInput.getText().toString();
            if (!inputText.isEmpty()) {
                ClipData data = ClipData.newPlainText("data", inputText);
                clipboardManager.setPrimaryClip(data);
                clipboardHistory.add(inputText);
                Toast.makeText(this, "Text Copied...", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Please enter some text...", Toast.LENGTH_SHORT).show();
            }
        });

        // Paste Text from Clipboard
        btnPaste.setOnClickListener(view -> {
            ClipData.Item item = clipboardManager.getPrimaryClip().getItemAt(0);
            String showText = item.getText().toString();

            if (!showText.isEmpty()) {
                txtShowText.setText(showText);
                Toast.makeText(this, "Text Pasted...", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "No text copied...", Toast.LENGTH_SHORT).show();
            }
        });

        // Show Clipboard History
        btnClipboard.setOnClickListener(view -> {
            if (clipboardHistory.isEmpty()) {
                Toast.makeText(this, "Clipboard is empty...", Toast.LENGTH_SHORT).show();
                return;
            }

            String[] items = clipboardHistory.toArray(new String[0]);

            new AlertDialog.Builder(this)
                    .setTitle("Clipboard")
                    .setItems(items, (dialog, which) -> {
                        txtShowText.setText(items[which]);
                        Toast.makeText(this, "Text Selected...", Toast.LENGTH_SHORT).show();
                    })
                    .show();
        });
    }
}
```

---

## How each button works

### btnCopy
1. Gets text from `edtInput`
2. If not empty → creates `ClipData` with the text
3. Sets it as primary clip using `clipboardManager.setPrimaryClip(data)`
4. Also adds text to `clipboardHistory` list
5. Shows Toast "Text Copied..."

### btnPaste
1. Gets the primary clip from `clipboardManager`
2. Gets first item using `getItemAt(0)`
3. Sets that text on `txtShowText`
4. Shows Toast "Text Pasted..."

### btnClipboard
1. Checks if `clipboardHistory` list is empty
2. If empty → shows Toast "Clipboard is empty..."
3. If not empty → converts list to `String[]`
4. Shows `AlertDialog` with all copied texts as a list
5. User taps any item → that text is set on `txtShowText`

> **Note:** Clipboard history resets when the app is closed since it is stored in memory (ArrayList). This is the same behaviour as the Android keyboard clipboard.

---

---

# Quick Reference

## dimens.xml naming convention

| Folder | Applies when |
|---|---|
| `values/` | Default — all devices |
| `values-sw480dp/` | Shortest side of screen >= 480dp |
| `values-w820dp/` | Current width >= 820dp (changes on rotate) |

## Vibration

| | Code |
|---|---|
| Get Vibrator | `(Vibrator) getSystemService(VIBRATOR_SERVICE)` |
| New way (API 26+) | `VibrationEffect.createOneShot(duration, amplitude)` |
| Old way (API 25-) | `vibrate(milliseconds)` |
| Permission needed | `android.permission.VIBRATE` |

## Clipboard

| | Code |
|---|---|
| Get ClipboardManager | `(ClipboardManager) getSystemService(CLIPBOARD_SERVICE)` |
| Copy text | `ClipData.newPlainText("label", text)` then `setPrimaryClip(data)` |
| Paste text | `getPrimaryClip().getItemAt(0).getText()` |
| Clipboard history | `ArrayList<String>` — add on every copy |
