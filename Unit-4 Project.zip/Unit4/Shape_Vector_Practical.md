# Shape & Vector Drawable Practical

## Objective

Learn how to create **Shape Drawables** and **Vector Drawables** in Android using XML files inside the `drawable` folder, display them in a dedicated Activity, and navigate to that Activity from `MainActivity`.

---

## What is a Shape Drawable?

A **Shape Drawable** is an XML file stored in the `res/drawable/` folder that defines a geometric shape (rectangle, oval, ring, line) with properties like color, border, corners, and gradient.

- Defined using the `<shape>` tag
- Used as a `background` attribute on any View
- Lightweight — no image file needed
- Scales perfectly on all screen sizes

### Shape Types Available

| Shape | Description |
|---|---|
| `rectangle` | Draws a rectangle (default shape) |
| `oval` | Draws an oval or circle |
| `ring` | Draws a ring/donut shape |
| `line` | Draws a horizontal line |

---

## What is a Vector Drawable?

A **Vector Drawable** is an XML file that defines a scalable graphic using mathematical path data (SVG-like format).

- Defined using the `<vector>` tag
- Used as `src` attribute on `ImageView`
- Scales to any size without losing quality (no pixelation)
- Smaller file size compared to PNG images

---

## Project Structure After This Practical

```
app/
└── src/
    └── main/
        ├── java/com/example/unit4/
        │   ├── MainActivity.java           ← Updated (added navigation)
        │   └── ShapeVectoreDemo.java       ← New Activity (created)
        └── res/
            ├── drawable/
            │   ├── shape_rectangle.xml     ← New (Shape)
            │   ├── shape_oval.xml          ← New (Shape)
            │   ├── shape_ring.xml          ← New (Shape)
            │   ├── vector_star.xml         ← New (Vector)
            │   └── vector_heart.xml        ← New (Vector)
            └── layout/
                ├── activity_main.xml       ← Updated (added button)
                └── activity_shape_vectore_demo.xml  ← New Layout
```

---

## Step-by-Step Implementation

---

## STEP 1 — Create Shape Drawable: Rectangle

**File path:** `app/src/main/res/drawable/shape_rectangle.xml`

Right-click on the `drawable` folder → New → Drawable Resource File → name it `shape_rectangle` → click OK.

Paste the following code:

```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="#4CAF50" />
    <corners android:radius="12dp" />
    <stroke android:width="2dp" android:color="#1B5E20" />
</shape>
```

### Code Explanation

| Tag / Attribute | Meaning |
|---|---|
| `android:shape="rectangle"` | Tells Android this shape is a rectangle |
| `<solid android:color="#4CAF50" />` | Fills the shape with green color |
| `<corners android:radius="12dp" />` | Rounds all 4 corners by 12dp |
| `<stroke android:width="2dp" android:color="#1B5E20" />` | Adds a dark green border of 2dp thickness |

---

## STEP 2 — Create Shape Drawable: Oval

**File path:** `app/src/main/res/drawable/shape_oval.xml`

Right-click on the `drawable` folder → New → Drawable Resource File → name it `shape_oval` → click OK.

```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="oval">
    <solid android:color="#2196F3" />
    <stroke android:width="2dp" android:color="#0D47A1" />
</shape>
```

### Code Explanation

| Tag / Attribute | Meaning |
|---|---|
| `android:shape="oval"` | Draws an oval (or circle if width = height) |
| `<solid android:color="#2196F3" />` | Fills the shape with blue color |
| `<stroke android:width="2dp" android:color="#0D47A1" />` | Adds a dark blue border |

> **Note:** There are no `<corners>` in oval because oval shapes are already curved.

---

## STEP 3 — Create Shape Drawable: Ring

**File path:** `app/src/main/res/drawable/shape_ring.xml`

Right-click on the `drawable` folder → New → Drawable Resource File → name it `shape_ring` → click OK.

```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="ring"
    android:innerRadiusRatio="3"
    android:thicknessRatio="8"
    android:useLevel="false">
    <solid android:color="#FF5722" />
</shape>
```

### Code Explanation

| Tag / Attribute | Meaning |
|---|---|
| `android:shape="ring"` | Draws a ring (donut/circle with hole) |
| `android:innerRadiusRatio="3"` | Inner hole size = total width ÷ 3 |
| `android:thicknessRatio="8"` | Ring thickness = total width ÷ 8 |
| `android:useLevel="false"` | **Required** — without this, the ring won't be visible |
| `<solid android:color="#FF5722" />` | Fills the ring with orange-red color |

> **Important:** `android:useLevel="false"` is mandatory for ring shapes. If you forget it, the ring will not appear on screen.

---

## STEP 4 — Create Vector Drawable: Star

**File path:** `app/src/main/res/drawable/vector_star.xml`

Right-click on the `drawable` folder → New → Drawable Resource File → name it `vector_star` → click OK.

```xml
<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="100dp"
    android:height="100dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFC107"
        android:pathData="M12,2 L15.09,8.26 L22,9.27 L17,14.14 L18.18,21.02 L12,17.77 L5.82,21.02 L7,14.14 L2,9.27 L8.91,8.26 Z" />
</vector>
```

### Code Explanation

| Tag / Attribute | Meaning |
|---|---|
| `<vector>` | Root tag for all vector drawables |
| `android:width="100dp"` | Display width of the vector image |
| `android:height="100dp"` | Display height of the vector image |
| `android:viewportWidth="24"` | Internal drawing canvas width (coordinate system) |
| `android:viewportHeight="24"` | Internal drawing canvas height (coordinate system) |
| `<path>` | Defines the actual shape to draw using path commands |
| `android:fillColor="#FFC107"` | Fills the path with yellow/amber color |
| `android:pathData="M12,2 L15.09..."` | SVG path commands that draw the star shape |

### Understanding pathData Commands

| Command | Meaning |
|---|---|
| `M x,y` | Move to point (x, y) — starting point |
| `L x,y` | Draw a straight Line to point (x, y) |
| `Z` | Close the path (connect back to start) |

---

## STEP 5 — Create Vector Drawable: Heart

**File path:** `app/src/main/res/drawable/vector_heart.xml`

Right-click on the `drawable` folder → New → Drawable Resource File → name it `vector_heart` → click OK.

```xml
<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="100dp"
    android:height="100dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#E91E63"
        android:pathData="M12,21.35 L10.55,20.03 C5.4,15.36 2,12.27 2,8.5 C2,5.41 4.42,3 7.5,3 C9.24,3 10.91,3.81 12,5.08 C13.09,3.81 14.76,3 16.5,3 C19.58,3 22,5.41 22,8.5 C22,12.27 18.6,15.36 13.45,20.03 Z" />
</vector>
```

### Code Explanation

| Tag / Attribute | Meaning |
|---|---|
| `android:fillColor="#E91E63"` | Fills the heart with pink/red color |
| `C x1,y1 x2,y2 x,y` | Cubic Bezier Curve — used to draw the curved sides of the heart |
| `android:pathData="M12,21.35..."` | Path commands that draw the heart shape using curves |

> **Note:** The heart uses `C` (Cubic Bezier Curve) commands in pathData to create smooth curved edges, unlike the star which only uses straight `L` (Line) commands.

---

## STEP 6 — Create the Layout File

**File path:** `app/src/main/res/layout/activity_shape_vectore_demo.xml`

Right-click on the `layout` folder → New → Layout Resource File → name it `activity_shape_vectore_demo` → click OK.

```xml
<?xml version="1.0" encoding="utf-8"?>
<ScrollView xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:padding="16dp">

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="vertical"
        android:gravity="center">

        <!-- Title -->
        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Shape &amp; Vector Demo"
            android:textSize="22sp"
            android:textStyle="bold"
            android:layout_marginBottom="20dp" />

        <!-- Rectangle Shape -->
        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Rectangle Shape"
            android:textSize="16sp"
            android:layout_marginBottom="6dp" />

        <View
            android:layout_width="200dp"
            android:layout_height="80dp"
            android:background="@drawable/shape_rectangle"
            android:layout_marginBottom="20dp" />

        <!-- Oval Shape -->
        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Oval Shape"
            android:textSize="16sp"
            android:layout_marginBottom="6dp" />

        <View
            android:layout_width="200dp"
            android:layout_height="100dp"
            android:background="@drawable/shape_oval"
            android:layout_marginBottom="20dp" />

        <!-- Ring Shape -->
        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Ring Shape"
            android:textSize="16sp"
            android:layout_marginBottom="6dp" />

        <View
            android:layout_width="120dp"
            android:layout_height="120dp"
            android:background="@drawable/shape_ring"
            android:layout_marginBottom="20dp" />

        <!-- Vector Star -->
        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Vector - Star"
            android:textSize="16sp"
            android:layout_marginBottom="6dp" />

        <ImageView
            android:layout_width="100dp"
            android:layout_height="100dp"
            android:src="@drawable/vector_star"
            android:layout_marginBottom="20dp" />

        <!-- Vector Heart -->
        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Vector - Heart"
            android:textSize="16sp"
            android:layout_marginBottom="6dp" />

        <ImageView
            android:layout_width="100dp"
            android:layout_height="100dp"
            android:src="@drawable/vector_heart"
            android:layout_marginBottom="20dp" />

    </LinearLayout>

</ScrollView>
```

### Code Explanation

| Widget / Attribute | Meaning |
|---|---|
| `<ScrollView>` | Wraps the whole layout so user can scroll if content overflows the screen |
| `<LinearLayout orientation="vertical">` | Stacks all children one below the other |
| `android:gravity="center"` | Centers all children horizontally |
| `<View android:background="@drawable/shape_rectangle">` | A blank View that shows the shape as its background |
| `<ImageView android:src="@drawable/vector_star">` | Displays the vector drawable as an image |

> **Key Difference:**
> - Shapes are applied as `background` on a `<View>`
> - Vectors are applied as `src` on an `<ImageView>`

---

## STEP 7 — Create the Java Activity File

**File path:** `app/src/main/java/com/example/unit4/ShapeVectoreDemo.java`

Right-click on your package folder → New → Java Class → name it `ShapeVectoreDemo` → click OK.

```java
package com.example.unit4;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class ShapeVectoreDemo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shape_vectore_demo);
    }
}
```

### Code Explanation

| Code | Meaning |
|---|---|
| `extends AppCompatActivity` | Makes this class an Android Activity |
| `onCreate()` | Called automatically when the Activity starts |
| `setContentView(R.layout.activity_shape_vectore_demo)` | Loads and displays the XML layout on screen |

---

## Shape vs Vector — Key Differences

| Feature | Shape Drawable | Vector Drawable |
|---|---|---|
| XML Tag | `<shape>` | `<vector>` |
| Used for | Simple geometric shapes | Complex icons and illustrations |
| Applied via | `android:background` on `<View>` | `android:src` on `<ImageView>` |
| Scalability | Limited | Scales perfectly at any size |
| Supports curves | No (only corners) | Yes (Bezier curves) |
| File size | Very small | Small |
| Best for | Buttons, cards, backgrounds | Icons, logos, illustrations |

---

## Common Shape Drawable Tags Reference

```xml
<shape android:shape="rectangle | oval | ring | line">

    <!-- Fill color -->
    <solid android:color="#COLOR" />

    <!-- Border -->
    <stroke android:width="2dp" android:color="#COLOR" />

    <!-- Rounded corners (rectangle only) -->
    <corners android:radius="10dp" />

    <!-- Gradient fill -->
    <gradient
        android:startColor="#COLOR1"
        android:endColor="#COLOR2"
        android:angle="90" />

    <!-- Padding inside the shape -->
    <padding android:left="10dp" android:top="10dp"
             android:right="10dp" android:bottom="10dp" />

</shape>
```

---

## Common Vector Drawable Tags Reference

```xml
<vector
    android:width="100dp"
    android:height="100dp"
    android:viewportWidth="24"
    android:viewportHeight="24">

    <path
        android:fillColor="#COLOR"
        android:strokeColor="#COLOR"
        android:strokeWidth="1"
        android:pathData="M ... L ... C ... Z" />

</vector>
```

### pathData Command Reference

| Command | Full Name | Description |
|---|---|---|
| `M x,y` | Move To | Move pen to point without drawing |
| `L x,y` | Line To | Draw straight line to point |
| `C x1,y1 x2,y2 x,y` | Cubic Bezier | Draw smooth curve |
| `Q x1,y1 x,y` | Quadratic Bezier | Draw simpler curve |
| `A rx,ry rot f1 f2 x,y` | Arc | Draw arc/ellipse segment |
| `Z` | Close Path | Connect back to starting point |

---

## Final Output

When you run the app:

1. `MainActivity` shows a list of all demos
2. Tap **"Shape & Vector Demo"** to open `ShapeVectoreDemo`
3. The screen shows all 5 drawables with labels:
   - ✅ Green Rounded Rectangle (Shape)
   - ✅ Blue Oval (Shape)
   - ✅ Orange Ring (Shape)
   - ✅ Yellow Star (Vector)
   - ✅ Pink Heart (Vector)

---

## Summary of All Files

| File | Location | Purpose |
|---|---|---|
| `shape_rectangle.xml` | `res/drawable/` | Green rounded rectangle shape |
| `shape_oval.xml` | `res/drawable/` | Blue oval shape |
| `shape_ring.xml` | `res/drawable/` | Orange ring shape |
| `vector_star.xml` | `res/drawable/` | Yellow star vector icon |
| `vector_heart.xml` | `res/drawable/` | Pink heart vector icon |
| `activity_shape_vectore_demo.xml` | `res/layout/` | Layout showing all shapes and vectors |
| `ShapeVectoreDemo.java` | `java/.../unit4/` | Activity that loads the layout |
| `activity_main.xml` | `res/layout/` | Updated — added navigation button |
| `MainActivity.java` | `java/.../unit4/` | Updated — added click listener |
| `AndroidManifest.xml` | `app/src/main/` | Updated — registered new Activity |
