# Text to Speech - Android Practical Guide

## What is Text to Speech?
Text to Speech (TTS) is a built-in Android feature that **reads out loud whatever text you give it**.  
Android provides a class called `TextToSpeech` to do this — no extra library needed.

---

## Tools Required
- Android Studio
- Android Device or Emulator (with speaker/volume on)
- Minimum SDK: API 21+

---

## Step 1 — Create a New Activity

1. Right click on your package → New → Activity → Empty Activity
2. Name it `TextToSpeechDemo`
3. This will create two files:
   - `TextToSpeechDemo.java` → Java logic file
   - `activity_text_to_speech_demo.xml` → Layout/UI file

---

## Step 2 — No Special Permission Needed in Manifest

> Text to Speech does **NOT** require any special permission in `AndroidManifest.xml`.  
> Android's TTS engine is built-in and works without any permission.

But you must make sure your activity is **registered** in the manifest.  
Android Studio does this automatically when you create a new activity.

### `AndroidManifest.xml` — Check this entry exists:

```xml
<activity
    android:name=".TextToSpeechDemo"
    android:exported="false" />
```

> If this line is missing, add it inside the `<application>` tag.

---

## Step 3 — Design the Layout (XML File)

Open `res/layout/activity_text_to_speech_demo.xml` and replace with:

```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:layout_margin="30dp"
    android:gravity="center"
    tools:context=".TextToSpeechDemo">

    <!-- Input box where user types text -->
    <EditText
        android:id="@+id/edtText"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:hint="Enter Any Sentence"
        android:gravity="center"
        android:textSize="16sp"
        android:layout_marginBottom="20dp"/>

    <!-- Button to trigger Text to Speech -->
    <Button
        android:id="@+id/btnText"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Click Here for Text to Speech"/>

    <!-- Displays the entered text on screen -->
    <TextView
        android:id="@+id/textView"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="70dp"
        android:gravity="center_horizontal"
        android:text=""
        android:textColor="@android:color/holo_red_dark"
        android:textSize="30sp"/>

</LinearLayout>
```

### UI Elements Used:
| ID | Type | Purpose |
|---|---|---|
| `edtText` | EditText | User types the text here |
| `btnText` | Button | Click to speak the text |
| `textView` | TextView | Displays the entered text on screen |

---

## Step 4 — Write the Java Code

Open `TextToSpeechDemo.java` and write:

```java
package com.example.yourpackagename;  // change this to your package name

import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class TextToSpeechDemo extends AppCompatActivity {

    EditText edtText;
    Button btnText;
    TextView textView;
    TextToSpeech textToSpeech;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_text_to_speech_demo);

        // Step 1: Connect XML views to Java variables
        edtText = findViewById(R.id.edtText);
        btnText = findViewById(R.id.btnText);
        textView = findViewById(R.id.textView);

        // Step 2: Create TextToSpeech object
        textToSpeech = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int i) {
                // Step 3: Check if TTS loaded without error
                if (i != TextToSpeech.ERROR) {
                    // Step 4: Set the speaking language
                    textToSpeech.setLanguage(Locale.US);
                }
            }
        });

        // Step 5: Button click - speak the text
        btnText.setOnClickListener(view -> {
            String toSpeak = edtText.getText().toString();  // read text from EditText
            textView.setText(toSpeak);                      // show text in TextView
            textToSpeech.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, null);  // speak it
        });
    }
}
```

---

## Code Explanation — Line by Line

### Imports
```java
import android.speech.tts.TextToSpeech;  // TTS engine class
import java.util.Locale;                  // for setting language
```

### Variables
```java
TextToSpeech textToSpeech;  // main object that speaks the text
```

### Creating TTS Object
```java
textToSpeech = new TextToSpeech(getApplicationContext(), listener);
```
- `getApplicationContext()` → tells TTS which app is using it
- `listener` → a callback that runs when TTS is ready to use

### onInit() Method
```java
public void onInit(int i) {
    if (i != TextToSpeech.ERROR) {
        textToSpeech.setLanguage(Locale.US);
    }
}
```
- `i` is a status code returned by Android
- If `i != ERROR` → TTS loaded successfully
- `setLanguage(Locale.US)` → sets American English accent

### speak() Method
```java
textToSpeech.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, null);
```
| Parameter | Meaning |
|---|---|
| `toSpeak` | The text to be spoken |
| `QUEUE_FLUSH` | Stop current speech and speak this immediately |
| `QUEUE_ADD` | Wait for current speech to finish, then speak |
| `null` | No extra bundle options needed |

---

## Step 5 — Working Flow

```
App Opens
    ↓
onCreate() runs → Layout loads on screen
    ↓
findViewById() → Java connects to UI elements
    ↓
TextToSpeech object created → Engine loads in background
    ↓
onInit() called → Language set to US English → TTS Ready ✅
    ↓
User types text in EditText
    ↓
User clicks Button
    ↓
getText().toString() → reads the typed text
    ↓
textView.setText() → displays text on screen
    ↓
textToSpeech.speak() → converts text to voice → plays on speaker 🔊
```

---

## Step 6 — Run the App

1. Connect your Android phone or start an emulator
2. Make sure **volume is turned up**
3. Click Run ▶ in Android Studio
4. Type any sentence in the input box
5. Click the button
6. The text will appear on screen and the device will **speak it out loud**

---

## Common Mistakes to Avoid

| Mistake | Fix |
|---|---|
| Activity not registered in Manifest | Android Studio adds it automatically, just verify |
| TTS speaks but no sound | Check device volume is not muted |
| App crashes on button click | Make sure `onInit()` ran successfully before calling `speak()` |
| Wrong language/accent | Change `Locale.US` to `Locale.UK`, `Locale.FRENCH`, etc. |
| `getText()` returns empty | User did not type anything — add a check before speaking |

---

## Available Locale Options

```java
textToSpeech.setLanguage(Locale.US);      // American English
textToSpeech.setLanguage(Locale.UK);      // British English
textToSpeech.setLanguage(Locale.FRENCH);  // French
textToSpeech.setLanguage(Locale.GERMAN);  // German
textToSpeech.setLanguage(Locale.JAPANESE);// Japanese
```

---

## Summary Table

| File | What you do in it |
|---|---|
| `AndroidManifest.xml` | Verify activity is registered (no extra permission needed) |
| `activity_text_to_speech_demo.xml` | Design UI — EditText, Button, TextView |
| `TextToSpeechDemo.java` | Write logic — create TTS, set language, speak on button click |

---

*Practical by: Android Development — Unit 4*
